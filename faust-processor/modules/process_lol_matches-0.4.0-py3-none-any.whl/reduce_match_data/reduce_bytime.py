"""Contains all functions to reduce the data from the bytime endpoint."""

import logging
from collections import defaultdict

from . import resources as rsc

logger = logging.getLogger(__name__)


def reduce_bytime_data(bytime: dict) -> None:
    """Reduce bytime data, done in two parts: participantFrames and the events.

    The participantFrames gets organized as a list of each metric, being the key the
    minute, with the participantId with the key and the value being the metrics
    dictonary. A list of the values for each minute of the game.
    EG:
        FROM: {
            "minute_0": {
                "participantId_1": {"metric_1": value,...,"metric_n": value}
                ,...,
                "participantId_10": {"metric_1": value,...,"metric_n": value}
            }
            ,...,
            "minute_n": {
                "participantId_1": {"metric_1": value,...,"metric_n": value},...,
                "participantId_10": {"metric_1": value,...,"metric_n": value}
            }
        }
        TO: {
            "participantId_1": {
                "metric_1": [value_0,...,value_n],
                ...,
                "metric_n": [value_0,...,value_n]
            }
            ,...,
            "participantId_10": {
                "metric_1": [value_0,...,value_n],
                ...,
                "metric_n": [value_0,...,value_n]
            }
        }

    The events gets organized as a json of each event, being the key the event type, and
    the value a list of the values for each event of the game. The list is ordered, so
    the first value of each metric is the value for the first event. To reconstruct the
    match, the "eventOrder" key is added to the event, which contains the order of the
    events in the match. That is, if the first event WARD_PLACED has a 3 in the
    eventOrder, that means than the third event in the match was a WARD_PLACED event and
    the values for all the metrics that compose the event are in the third position of
    the list.
    EG:
        FROM: {
            "minute_0": {
                "event_1": {
                    "metric_1": value,
                    ...,
                    "metric_n": value,
                    gameOrd: value, typeOrd: value
                }
                ,...,
                "event_n": {
                    "metric_1": value,
                    ...,
                    "metric_n": value,
                    gameOrd: value, typeOrd: value
                }
            }
            ,...,
            "minute_n": {
                "event_1": {
                    "metric_1": value,
                    ...,
                    "metric_n": value,
                    gameOrd: value, typeOrd: value
                }
                ,...,
                "event_n": {
                    "metric_1": value,
                    ...,
                    "metric_n": value,
                    gameOrd: value, typeOrd: value
                }
            }
        }
        TO: {
            "event_1": {
                "eventOrder": [num_1_1,...,num_m_1],
                "metric_1": [value_0,...,value_m],
                ...,
                "metric_n": [value_0,...,value_m]
            }
            ,...,
            "event_n": {
                "eventOrder": [num_1_n,...,num_m_n],
                "metric_1": [value_0,...,value_m],...,
                "metric_n": [value_0,...,value_m]
            }
        }

    Note: not all matches have the same amount of minutes nor events.

    Args:
    ----
        bytime (json): The input data in JSON format.

    """
    participantsframes_per_minutes = {}
    events_per_minutes = {}

    data = bytime["info"].pop("frames", [])

    event_counters = {"total": 0}
    for index, frame in enumerate(data, start=0):
        # we treat every event to easily reduce it later
        participantsframes_per_minutes[index] = process_participant_frames(
            frame["participantFrames"],
        )
        events_per_minutes[index] = process_events(frame["events"], event_counters)

    participant_frames = rehandle_participants(participantsframes_per_minutes)
    events, linked_events, original_victim_damages = rehandle_events(
        events_per_minutes,
    )
    bytime["info"]["events"] = events
    bytime["info"]["participantFrames"] = participant_frames
    bytime["info"]["linkedEvents"] = linked_events
    bytime["info"]["victimDamage"] = original_victim_damages


def process_events(events: list[dict], event_counters: dict[str, int]) -> list[dict]:
    """Logic of how to process the events in the match from the bytime representation.

    Given the list of all events in bytime, it combines the event with gameId,
    participants, matchId, and dataVersion and treats the 'position' key. This function
    aims to process the data into a more manageable form

    Args:
    ----
        events (list[dict]): The list of all events in bytime per minute.
        event_counters (dict[str, int]): The counters of the events in the match.

    Returns:
    -------
        list[dict]: The list of all events in bytime treated

    """
    results = []
    linked_events_types = ["CHAMPION_SPECIAL_KILL", "DRAGON_SOUL_GIVEN"]
    for event in events:
        event_type = event["type"]
        if event_type not in linked_events_types:
            event_counters["total"] += 1
            if event_type not in event_counters:
                event_counters[event_type] = 0
            event_counters[event_type] += 1

        # Handle 'position' key
        if "position" in event:
            position = event.pop("position")
            event["position"] = (position.get("x"), position.get("y"))

        # Combine event with gameId, participants, matchId, and dataVersion
        combined_data = {
            **event,
            "eventOrd": event_counters["total"],
        }

        results.append(combined_data)

    return results


def process_participant_frames(participant_frame: dict) -> dict:
    """Treats the participant data from the bytime representation.

    Treats participant_frame data, flattens damageStats and championStats, writes
    position as a tuple, and removes participantId and level keys, which are not
    necessary. The participants are treated frame by frame

    Args:
    ----
        participant_frame (dict): One minute of the participant data from the match.

    Returns:
    -------
        list[dict]: The list of all events in bytime treated

    """
    players = {}
    for player in range(1, 11):
        player_frame = participant_frame[str(player)]

        _ = player_frame.pop("participantId")
        _ = player_frame.pop("level")

        # Handle 'position' key
        if "position" in player_frame:
            position = player_frame.pop("position")
            player_frame["position"] = (
                position.get("x", None),
                position.get("y", None),
            )

        if "championStats" in player_frame:
            cs = player_frame.pop("championStats")
            for metric in cs:
                player_frame[f"championStat_{metric}"] = cs.get(metric)

        if "damageStats" in player_frame:
            ds = player_frame.pop("damageStats")
            for metric in ds:
                player_frame[f"damageStat_{metric}"] = ds.get(metric)

        players[player] = player_frame
    return players


def rehandle_participants(participants_data: dict) -> None:
    """Reformats the participant data from the bytime representation.

    participants_data = {
        minute_0: {
            participantId_1: {metric: value, ...},
            ...,
            participantId_10: {metric: value, ...}
        },
        ...,
        minute_n: {
            participantId_1: {metric: value, ...},
            ...,
            participantId_10: {metric: value, ...}
        }
    }
    to
    {
        metric_1: {
            participantId_1: [value_0, ..., value_n],
            ...,
            participantId_10: [value_0, ..., value_n]
        },
        ...,
        metric_n: {
            participantId_1: [value_0, ..., value_n],
            ...,
            participantId_10: [value_0, ..., value_n]
        }
    }
    where the position in the list is the minute which the value has been taken from the
    match.

    Args:
    ----
        participants_data (dict): The participant data from the match.

    Returns:
    -------
        dict: The participant data organized by metric.

    """
    # all the metrics and participants_id are common in every minute
    metrics = list(participants_data[0][1].keys())
    minutes = list(participants_data.keys())
    participants_id = list(participants_data[0].keys())

    return {
        metric: {
            participant_id: [
                participants_data[minute][participant_id][metric] for minute in minutes
            ]
            for participant_id in participants_id
        }
        for metric in metrics
    }


def summary_damage(damage_records: dict) -> dict:
    """Sum up damage dealt and recieved in each champion kill for participantId.

    The summary is just the magic, physical and true damage dealt and received by each
    participant, which are in the damages list dictionary.

    Args:
    ----
        damages (list): List of the damage types to be parsed.
        damage_records (list): List of damage records for a given event.

    Returns:
    -------
        dict: The damage dealt and received by each participant.

    """
    damage_per_type = {damage: {} for damage in rsc.DAMAGES}
    for damage in rsc.DAMAGES:
        for record in damage_records:
            participant_id = record["participantId"]
            damage_executed = record[damage]
            if participant_id not in damage_per_type[damage]:
                damage_per_type[damage][participant_id] = 0
            damage_per_type[damage][participant_id] += damage_executed

    return damage_per_type


def rehandle_events(events_per_minutes: dict) -> list[dict, dict]:
    """Reorder the events data.

    Returns a dictionary with the keys being the event type and the values
    a list of instances of that event

    Args:
    ----
        events_per_minutes (dict): The events data from the match.

    Returns:
    -------
        dict: The events data organized by event type.

    """
    # linked bytime events
    linked_events_type = ["CHAMPION_SPECIAL_KILL", "DRAGON_SOUL_GIVEN"]
    # list all the events to be iterated upon. This changes per match.
    # sorted to ensure correct comparison in unittests
    events_happened = sorted(
        {
            event.get("type")
            for events in events_per_minutes.values()
            for event in events
        },
    )
    # Initialize the result dictionary
    result = {
        event: defaultdict(list)
        for event in events_happened
        if event not in linked_events_type
    }
    linked_events = {
        event: defaultdict(list)
        for event in events_happened
        if event in linked_events_type
    }
    counter_events = {event: 0 for event in events_happened}
    original_victim_damages = {}

    for events in events_per_minutes.values():
        for event in events:
            if event["type"] in linked_events_type:
                treat_linked_event(event, linked_events)
            else:
                treat_events(event, result, counter_events, original_victim_damages)

    if "CHAMPION_SPECIAL_KILL" in linked_events:
        cross_reference_special_events(
            result["CHAMPION_KILL"],
            linked_events["CHAMPION_SPECIAL_KILL"],
        )
    if "DRAGON_SOUL_GIVEN" in linked_events:
        cross_reference_special_events(
            result["ELITE_MONSTER_KILL"],
            linked_events["DRAGON_SOUL_GIVEN"],
        )
    return dict(result), dict(linked_events), original_victim_damages


def treat_linked_event(
    event: dict,
    linked_events: dict,
) -> None:
    """Process linked events from bytime.

    Args:
    ----
        event (dict): _description_
        linked_events (dict): _description_

    """
    event_type = event.pop("type")

    for metric, value in event.items():
        linked_events[event_type][metric] += [value]


def treat_events(
    event: dict,
    result: dict,
    counter_events: dict,
    original_victim_damages: dict,
) -> None:
    """Process non dependant bytime events.

    Args:
    ----
        event (dict): event data
        result (dict): dict to fill with the processed data
        counter_events (dict): counter of the events to fill
        original_victim_damages (dict): original data from victim damage

    """
    event_type = event.pop("type")
    event_id = event.get("eventOrd")

    # if the event is a kill, we need to parse the damage dealt and received
    if event_type == "CHAMPION_KILL":
        victim_damage_dealt = event.pop("victimDamageDealt", [])
        victim_damage_received = event.pop("victimDamageReceived", [])
        original_victim_damages[event_id] = {
            "victimDamageDealt": victim_damage_dealt,
            "victimDamageReceived": victim_damage_received,
        }

        process_damage(
            result,
            "victimDamageReceived",
            victim_damage_received,
        )
        process_damage(result, "victimDamageDealt", victim_damage_dealt)

    # if the event has assists, we must add "assistingParticipantIds"
    if event_type in rsc.EVENTS_WITH_ASSISTS:
        event.setdefault("assistingParticipantIds", [])

    for metric, value in event.items():
        # checks if a key appears but hasn't appeared in the past.
        if metric not in result[event_type]:
            # if it has, gets filled with None to keep the eventOrder structure
            result[event_type][metric] = [None] * counter_events[event_type]
        result[event_type][metric] += [value]

    counter_events[event_type] += 1

    for metric in result[event_type]:
        events_processed = len(result[event_type][metric])
        counted_events = counter_events[event_type]
        victim_damage_in = metric in [
            "victimDamageDealt",
            "victimDamageReceived",
        ]
        # if the events seem is smaller than counted, we need to fill the list
        if events_processed < counted_events and not victim_damage_in:
            result[event_type][metric] += [None]


def process_damage(result: dict, key: str, victim_damage: dict) -> None:
    """Process the damage dealt and received by the participants in the match.

    Logic of how to process the damage dealt and received by the participants.
    If there is no damage dealt, we add an empty dictionary to keep the eventOrder
    structure consistent.
    If there is damage dealt, we summarize the damage dealt and received by each
    participant and type found (magic, physical, and true).

    Args:
    ----
        result (dict): The result dictionary to be updated. Passed by reference, we are
            modifiying the original dictionary.
        key (str): The key (victimDamageDealt or victimDamageReceived).
        victim_damage (dict): The damage dealt and received by the participants from
            CHAMPION KILL event

    """
    if victim_damage:
        # if the has damage dealt, we need to parse the damage dealt and received
        if key not in result["CHAMPION_KILL"]:
            result["CHAMPION_KILL"][key] = {damage: [] for damage in rsc.DAMAGES}
        damage_summarized = summary_damage(victim_damage)
        for damage in rsc.DAMAGES:
            result["CHAMPION_KILL"][key][damage] += [damage_summarized[damage]]
    else:
        # if no damage dealt, add an empty dictionary to keep the eventOrder structure
        if key not in result["CHAMPION_KILL"]:
            result["CHAMPION_KILL"][key] = {damage: [] for damage in rsc.DAMAGES}
        for damage in rsc.DAMAGES:
            result["CHAMPION_KILL"][key][damage] += [{}]


def cross_reference_special_events(
    primary_event: dict,
    special_events: dict,
) -> None:
    """Link champion kill and special kill events and elite monster kill and dragon soul given events using two-pointer technique.

    Args:
    ----
        primary_event (dict): reduced primary events
        special_events (dict): reduced special events

    """
    primary_event_timestamps = primary_event["timestamp"]
    primary_event_orders = primary_event["eventOrd"]

    special_event_timestamps = special_events["timestamp"]
    special_event_orders = special_events["eventOrd"]

    i, j = 0, 0
    while i < len(special_event_timestamps) and j < len(primary_event_timestamps):
        if special_event_timestamps[i] == primary_event_timestamps[j]:
            # Timestamps match, now check event order
            if special_event_orders[i] != primary_event_orders[j]:
                special_event_orders[i] = primary_event_orders[j]
            i += 1
            j += 1
        elif special_event_timestamps[i] < primary_event_timestamps[j]:
            # Special event is before the current event, move to next special event
            i += 1
        else:
            # Event is before the current special event, move to next champion event
            j += 1
