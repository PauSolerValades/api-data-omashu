"""Contains all the functions to."""

import logging
from collections import defaultdict

from .resources import (
    INFO_KEYS,
    ITEM_KEYS,
    PARTICIPANT_KEYS_TO_INFO,
    PARTICIPANTS_100,
    PARTICIPANTS_200,
    PLAYER_CHALLENGES_KEYS,
    PLAYER_KEYS,
    SUMMONER_METRICS,
    TEAM_CHALLENGES_KEYS,
    TEAM_KEYS,
)
from .sort_pid_pos import player_to_team, team_position_to_participant_id

known_metrics = (
    INFO_KEYS
    + PARTICIPANT_KEYS_TO_INFO
    + PLAYER_CHALLENGES_KEYS
    + PLAYER_KEYS
    + TEAM_CHALLENGES_KEYS
    + TEAM_KEYS
)


logger = logging.getLogger("reduce")


def reduce_postmatch_data(postmatch: dict) -> None:
    """Reduce the postmatch data into gamedata, build, and bans.

    The participant data gets compressed from all the variables 10 times, one for each
    participant into a single dictionary with the metric as the key, and the value as a
    dictonary with participantId as the key and the value as the value, grouped by
    player or team variable.
    EG:
    [{"metric": value, "participantId": 1},...,{"metric": value, "participantId": 10}]
    to:
    {"players": {"metric": {1: value, 2: value, ..., 10: value}},
    "teams":{"metric": {100: value, 200: value}}}

    The build data gets compressed from all the variables 10 times, one for each
    participant into a single dictionary with the metric as the key, and the value as a
    dictonary with participantId as the key and the value as the value, like the
    participant data.

    The bans data just gets separated from the participants data and separated into a
    single dictionary.

    Args:
    ----
        postmatch (dict): The postmatch data.

    """
    reduced_data = process_postmatch(postmatch)
    gamedata = {}

    to_info = reduced_data.pop("info")

    gamedata["playerChallenges"] = pivot_player_data(
        reduced_data["gamedata"].pop("playerChallenges"),
    )
    gamedata["players"] = pivot_player_data(
        reduced_data["gamedata"].pop("players"),
    )

    gamedata["teamChallenges"] = pivot_team_data(
        reduced_data["gamedata"].pop("teamChallenges"),
    )
    gamedata["teams"] = pivot_team_data(
        reduced_data["gamedata"].pop("teams"),
    )
    gamedata["unclassified"] = pivot_player_data(
        reduced_data["gamedata"].pop("unclassified"),
    )

    build = pivot_player_data(reduced_data.pop("build"))
    bans = pivot_player_data(reduced_data.pop("bans", {}))

    team_position_id, shuffled = team_position_to_participant_id(
        gamedata["players"]["teamPosition"],
    )

    postmatch["metadata"]["teamPositionId"] = team_position_id
    postmatch["metadata"]["positionShuffled"] = shuffled
    postmatch["info"]["gamedata"] = gamedata
    postmatch["info"]["build"] = build
    postmatch["info"]["bans"] = bans
    postmatch["info"].update(to_info)


def process_postmatch(match: dict) -> dict:
    """Split data into bans, build and gamedata and to_info.

    - Separates the data into bans, gamedata, build and to_info.
    - Denestes some variables that are nested in the JSON (playerChallenges,
        teamChallenges, missions, objectives).

    Args:
    ----
        match (dict): match data dict

    Returns:
    -------
        dict: postmatch data dict

    Raises:
    ------
        ValueError: If the participantId is not valid.

    """
    teams = match["info"].pop("teams", [])
    participants = match["info"].pop("participants", [])

    objectives = [
        team.pop("objectives", {}) for team in teams
    ]  # teams will always have 2 elements
    players_champions = {}
    gamedata = {
        k: {}
        for k in [
            "players",
            "teams",
            "playerChallenges",
            "teamChallenges",
            "unclassified",
        ]
    }
    postmatch = {}
    builds = {}

    for participant in participants:
        # bans, build i gamedata
        participant_id = participant.pop("participantId", None)
        champion_id = participant.get("championId", None)

        # bans, build
        team_position = participant.get("teamPosition", None)
        champion_name = participant.pop("championName", None)

        # build
        perks = participant.pop("perks", {})
        items_json = {item: participant.pop(item, None) for item in ITEM_KEYS}
        summoner_json = {
            summoner: participant.pop(summoner, None) for summoner in SUMMONER_METRICS
        }
        legendary_items = participant["challenges"].pop("legendaryItemUsed", None)
        items_json["legendaryItemsUsed"] = legendary_items

        team_id = participant.get("teamId", None)  # bans

        player_info = {
            "participantId": participant_id,
            "championId": champion_id,
            "championName": champion_name,
            "teamId": team_id,
        }
        players_champions[participant_id] = player_info

        builds[participant_id] = process_build(
            player_info,
            perks,
            items_json,
            summoner_json,
            team_position,
        )

        # objectives are team based, so we need to pass the players team objective
        if participant_id in PARTICIPANTS_100:
            objective = objectives[0]
        elif participant_id in PARTICIPANTS_200:
            objective = objectives[1]
        else:
            logger.error("ERROR: Non valid participantId")
            msg = "Non valid participantId"
            raise ValueError(msg)

        (
            gamedata["players"][participant_id],
            gamedata["teams"][participant_id],
            gamedata["playerChallenges"][participant_id],
            gamedata["teamChallenges"][participant_id],
            gamedata["unclassified"][participant_id],
            to_info,
        ) = process_gamedata(participant, objective)

    postmatch["bans"] = process_bans(teams, players_champions)
    postmatch["gamedata"] = dict(gamedata)
    postmatch["build"] = builds
    postmatch["info"] = to_info

    return postmatch


def process_gamedata(
    participant: dict,
    objective: dict[str, dict],
) -> tuple[dict, dict, dict, dict]:
    """Process the game data for a specific participant or team in a match.

    Filtrates the variables into four types:
    - players: a variable that changes for each player.
    - teams: a variable that has the same value for all players in the team.
    - participant_keys_to_info: a variable that has the same value for all players in
        the match but is in the participants dict.
    - unclassified: a variable that is not in the resources for participants. This is
        used to log the variables that are not in the resources.

    Args:
    ----
        participant (dict): Data of the participant.
        objective (list[dict[str, dict]]): List of objectives for the participant.

    Returns:
    -------
        (tuple): combined_players_data(dict), combined_teams_data(dict)

    """
    results = {
        "players": {},
        "playerChallenges": {},
        "teams": {},
        "teamChallenges": {},
        "unclassified": {},
    }

    # process the nested data challenges
    challenges = participant.pop("challenges", {})
    missions = participant.pop("missions", {})
    objectives = {
        f"team{nested_key.capitalize()}{key.capitalize()}": value
        for key, values in objective.items()
        for nested_key, value in values.items()
    }
    go_to_info_keys = {}

    for key in participant:
        classify_keys_participants(key, results, participant, go_to_info_keys)

    for key in challenges:
        classify_keys_challenges(key, results, challenges, go_to_info_keys)

    combined_player_data = {
        **results["players"],
        **missions,
    }
    combined_team_data = {**results["teams"], **objectives}

    return (
        combined_player_data,
        combined_team_data,
        results["playerChallenges"],
        results["teamChallenges"],
        results["unclassified"],
        go_to_info_keys,
    )


def classify_keys_participants(
    key: str,
    results: dict,
    participant: dict,
    go_to_info_keys: list,
) -> None:
    """Classify the keys in the participant data.

    Given the resources lists, classifies the participant (not challenger) keys into
    players, teams, participant_keys_to_info and unclassified.

    Args:
    ----
        key (str): The key to classify.
        results (dict): The dictionary to store the results.
        participant (dict): The participant data to classify
        go_to_info_keys (list): The keys that go to the info dict.

    """
    if key in PLAYER_KEYS:
        results["players"][key] = participant[key]
    elif key in TEAM_KEYS:
        results["teams"][key] = participant[key]
    elif key in PARTICIPANT_KEYS_TO_INFO:
        go_to_info_keys[key] = participant[key]

    if key not in known_metrics:
        results["unclassified"][key] = participant[key]
        logger.warning("Key %s not found in resources for participants", key)


def classify_keys_challenges(
    key: str,
    results: dict,
    challenges: dict,
    go_to_info_keys: list,
) -> None:
    """Classify the keys in the challenges data.

    Given the resources lists, classifies the challenges keys into players, teams,
    participant_keys_to_info and unclassified.

    Args:
    ----
        key (str): The key to classify.
        results (dict): The dictionary to store the results.
        challenges (dict): The challenges data to classify
        go_to_info_keys (list): The keys that go to the info dict.

    """
    if key in PLAYER_CHALLENGES_KEYS:
        results["playerChallenges"][key] = challenges[key]
    elif key in TEAM_CHALLENGES_KEYS:
        results["teamChallenges"][key] = challenges[key]
    elif key in PARTICIPANT_KEYS_TO_INFO:
        go_to_info_keys[key] = challenges[key]

    if key not in known_metrics:
        results["unclassified"][key] = challenges[key]
        logger.warning("Key %s not found in resources in challenges", key)


def process_bans(teams: list, player_champions: dict) -> dict:
    """Process the bans data for a given match.

    Args:
    ----
        teams (list): List of teams participating in the match.
        matchId (int): ID of the match.
        player_champions (dict): Dictionary mapping pickTurn to player champions.

    Returns:
    -------
        return_bans (dict): bans data processed

    """
    return_bans = {}
    for team in teams:
        bans = team.pop("bans", [])

        for ban in bans:
            pick_turn = ban.get("pickTurn", 0)
            ban_renamed = {f"{key}Banned": value for key, value in ban.items()}

            combined_data = {
                **ban_renamed,
                **team,
                **player_champions[pick_turn],
            }
            participant_id = combined_data.pop("participantId")

            return_bans[participant_id] = combined_data

    return return_bans


def process_build(
    player_info: dict,
    perks: dict,
    items: dict,
    summoner: dict,
    team_position: str,
) -> dict:
    """Process the build data for a match.

    Args:
    ----
        player_info (dict): Information about the player.
        perks (dict): Perks data for the player.
        items (dict): Items data for the player.
        summoner (dict): Summoner data for the player.
        team_position (str): The position of the player in the team.

    Returns:
    -------
        combined_data (dict): build data processed

    """
    stat_perks = perks.pop("statPerks", {})
    styles = perks.pop("styles", {})
    processed_stat_perks = {
        f"statPerks{key.capitalize()}": value for key, value in stat_perks.items()
    }

    processed_styles = {}
    for style_index, style in enumerate(styles):
        for selection_index, selection in enumerate(style["selections"]):
            for key, value in selection.items():
                new_key = (
                    f"stylesSelections{style_index}{selection_index}{key.capitalize()}"
                )
                processed_styles[new_key] = value

    return {
        "teamPosition": team_position,
        **summoner,
        **player_info,
        **processed_stat_perks,
        **processed_styles,
        **items,
    }


def pivot_player_data(data: dict) -> dict:
    """Convert participant dict from a postmatch.

    From
    {
        1: {"metric_1": value, ..., "metric_n": value},
        ...,
        10: {"metric_1": value, ..., "metric_n": value}
    }
    To
    {
        "metric_1": {"1": value, ..., "10": value},
        ...,
        "metric_n": {1: value, ..., 10: value},
    }
    Reducing considerably the size of the data.

    Args:
    ----
        data (dict): The data to reduce.

    Returns:
    -------
        dict: The reduced data.

    """
    per_player_data = defaultdict(lambda: defaultdict(dict))
    for key, values in data.items():
        for metric, player_value in values.items():
            per_player_data[metric][key] = player_value
    return dict(per_player_data)


def pivot_team_data(data: dict) -> dict:
    """Convert participants and teams dict from a postmatch.

    From
    {
        1: {"metric_1": value, ..., "metric_n": value},
        ...,
        10: {"metric_1": value, ..., "metric_n": value}
    }
    And
    {
        100: {"metric_1": value, ..., "metric_n": value},
        200: {"metric_1": value, ..., "metric_n": value}
    }
    To
    {
        "metric_1": {"100": value, "200": value},
        ...,
        "metric_n": {"100": value, "200": value}
    }
    Reducing considerably the size of the data.

    Args:
    ----
        data (dict): The data to reduce.

    Returns:
    -------
        dict: The reduced data.

    """
    per_team_data = defaultdict(lambda: defaultdict(dict))
    for key, values in data.items():
        for metric, team_value in values.items():
            per_team_data[metric][player_to_team(key)] = team_value
    return dict(per_team_data)
