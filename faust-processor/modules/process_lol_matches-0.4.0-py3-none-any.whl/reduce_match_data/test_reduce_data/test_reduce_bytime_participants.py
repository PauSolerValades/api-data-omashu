"""Tests for reduce_bytime_participants.py."""

import sys
import unittest
from collections import defaultdict
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))


from reduce_match_data.reduce_bytime import (
    process_events,
    process_participant_frames,
    rehandle_events,
    rehandle_participants,
    summary_damage,
)


class TestReduceBytimeParticipants(unittest.TestCase):
    """Test class for reduce_bytime_participants.py."""

    def test_reduce_rehandle_participants(self) -> None:
        """Test rehandle_participants function."""
        # Test data
        data = {
            0: {
                1: {"metric1": 10, "metric2": 2},
                2: {"metric1": 30, "metric2": 4},
                3: {"metric1": 50, "metric2": 6},
            },
            1: {
                1: {"metric1": 20, "metric2": 3},
                2: {"metric1": 30, "metric2": 4},
                3: {"metric1": 55, "metric2": 7},
            },
            2: {
                1: {"metric1": 30, "metric2": 4},
                2: {"metric1": 35, "metric2": 5},
                3: {"metric1": 60, "metric2": 6},
            },
        }

        # Expected result
        expected_result = {
            "metric1": {
                1: [10, 20, 30],
                2: [30, 30, 35],
                3: [50, 55, 60],
            },
            "metric2": {
                1: [2, 3, 4],
                2: [4, 4, 5],
                3: [6, 7, 6],
            },
        }

        # Call the function
        result = rehandle_participants(data)
        # Assert the result
        self.assertEqual(result, expected_result)

    def test_reduce_process_events(self) -> None:
        """Test process_events function."""
        data = [
            {
                "position": {
                    "x": 12,
                    "y": 10,
                },
                "key1": 14,
                "key2": 1,
                "type": "Type1",
            },
            {
                "key3": 21,
                "key4": 4,
                "type": "Type2",
            },
            {
                "position": {
                    "x": 15,
                    "y": 18,
                },
                "key1": 10,
                "key2": 5,
                "type": "Type1",
            },
            {
                "position": {
                    "x": 54,
                    "y": 45,
                },
                "key1": 21,
                "key2": 13,
                "type": "Type3",
            },
            {
                "key3": 32,
                "key4": 12,
                "type": "Type2",
            },
        ]
        event_counters = {"total": 22}

        # Expected result
        expected_result = [
            {
                "position": (12, 10),
                "key1": 14,
                "key2": 1,
                "type": "Type1",
                "eventOrd": 23,
            },
            {
                "key3": 21,
                "key4": 4,
                "type": "Type2",
                "eventOrd": 24,
            },
            {
                "position": (15, 18),
                "key1": 10,
                "key2": 5,
                "type": "Type1",
                "eventOrd": 25,
            },
            {
                "position": (54, 45),
                "key1": 21,
                "key2": 13,
                "type": "Type3",
                "eventOrd": 26,
            },
            {
                "key3": 32,
                "key4": 12,
                "type": "Type2",
                "eventOrd": 27,
            },
        ]

        # Call the function
        result = process_events(data, event_counters)
        # Assert the result
        self.assertEqual(result, expected_result)

    def test_reduce_process_participant_frames(self) -> None:
        """Test process_participantFrames function."""
        # Test data
        data = {
            "1": {
                "participantId": 61,
                "level": 3,
                "position": {
                    "x": 21,
                    "y": 19,
                },
                "championStats": {
                    "keyCS1": 0,
                    "keyCS2": 2,
                    "keyCS3": 1,
                },
                "damageStats": {
                    "keyDS1": 8,
                    "keyDS2": 5,
                    "keyDS3": 3,
                },
                "key1": 10,
                "key2": 2,
                "key3": 5,
            },
            "2": {
                "participantId": 97,
                "level": 12,
                "position": {
                    "x": 32,
                    "y": 23,
                },
                "championStats": {
                    "keyCS1": 3,
                    "keyCS2": 4,
                    "keyCS3": 1,
                },
                "damageStats": {
                    "keyDS1": 1,
                    "keyDS2": 3,
                    "keyDS3": 2,
                },
                "key1": 3,
                "key2": 4,
                "key3": 9,
            },
            "3": {
                "participantId": 72,
                "level": 2,
                "position": {
                    "x": 34,
                    "y": 43,
                },
                "championStats": {
                    "keyCS1": 3,
                    "keyCS2": 3,
                    "keyCS3": 4,
                },
                "damageStats": {
                    "keyDS1": 2,
                    "keyDS2": 2,
                    "keyDS3": 1,
                },
                "key1": 2,
                "key2": 4,
                "key3": 2,
            },
            "4": {
                "participantId": 62,
                "level": 4,
                "position": {
                    "x": 11,
                    "y": 25,
                },
                "championStats": {
                    "keyCS1": 4,
                    "keyCS2": 1,
                    "keyCS3": 3,
                },
                "damageStats": {
                    "keyDS1": 1,
                    "keyDS2": 3,
                    "keyDS3": 4,
                },
                "key1": 5,
                "key2": 3,
                "key3": 4,
            },
            "5": {
                "participantId": 60,
                "level": 3,
                "position": {
                    "x": 34,
                    "y": 54,
                },
                "championStats": {
                    "keyCS1": 5,
                    "keyCS2": 5,
                    "keyCS3": 3,
                },
                "damageStats": {
                    "keyDS1": 8,
                    "keyDS2": 4,
                    "keyDS3": 5,
                },
                "key1": 3,
                "key2": 6,
                "key3": 1,
            },
            "6": {
                "participantId": 54,
                "level": 6,
                "position": {
                    "x": 76,
                    "y": 56,
                },
                "championStats": {
                    "keyCS1": 4,
                    "keyCS2": 2,
                    "keyCS3": 3,
                },
                "damageStats": {
                    "keyDS1": 4,
                    "keyDS2": 5,
                    "keyDS3": 1,
                },
                "key1": 0,
                "key2": 1,
                "key3": 3,
            },
            "7": {
                "participantId": 30,
                "level": 6,
                "position": {
                    "x": 23,
                    "y": 32,
                },
                "championStats": {
                    "keyCS1": 5,
                    "keyCS2": 1,
                    "keyCS3": 3,
                },
                "damageStats": {
                    "keyDS1": 4,
                    "keyDS2": 5,
                    "keyDS3": 1,
                },
                "key1": 1,
                "key2": 2,
                "key3": 1,
            },
            "8": {
                "participantId": 20,
                "level": 2,
                "position": {
                    "x": 31,
                    "y": 12,
                },
                "championStats": {
                    "keyCS1": 0,
                    "keyCS2": 3,
                    "keyCS3": 1,
                },
                "damageStats": {
                    "keyDS1": 1,
                    "keyDS2": 0,
                    "keyDS3": 2,
                },
                "key1": 7,
                "key2": 6,
                "key3": 8,
            },
            "9": {
                "participantId": 12,
                "level": 13,
                "position": {
                    "x": 11,
                    "y": 8,
                },
                "championStats": {
                    "keyCS1": 4,
                    "keyCS2": 1,
                    "keyCS3": 3,
                },
                "damageStats": {
                    "keyDS1": 1,
                    "keyDS2": 3,
                    "keyDS3": 2,
                },
                "key1": 8,
                "key2": 9,
                "key3": 0,
            },
            "10": {
                "participantId": 22,
                "level": 7,
                "position": {
                    "x": 15,
                    "y": 21,
                },
                "championStats": {
                    "keyCS1": 4,
                    "keyCS2": 1,
                    "keyCS3": 3,
                },
                "damageStats": {
                    "keyDS1": 2,
                    "keyDS2": 6,
                    "keyDS3": 9,
                },
                "key1": 0,
                "key2": 1,
                "key3": 2,
            },
        }

        # Expected result
        expected_result = {
            1: {
                "key1": 10,
                "key2": 2,
                "key3": 5,
                "position": (21, 19),
                "championStat_keyCS1": 0,
                "championStat_keyCS2": 2,
                "championStat_keyCS3": 1,
                "damageStat_keyDS1": 8,
                "damageStat_keyDS2": 5,
                "damageStat_keyDS3": 3,
            },
            2: {
                "key1": 3,
                "key2": 4,
                "key3": 9,
                "position": (32, 23),
                "championStat_keyCS1": 3,
                "championStat_keyCS2": 4,
                "championStat_keyCS3": 1,
                "damageStat_keyDS1": 1,
                "damageStat_keyDS2": 3,
                "damageStat_keyDS3": 2,
            },
            3: {
                "key1": 2,
                "key2": 4,
                "key3": 2,
                "position": (34, 43),
                "championStat_keyCS1": 3,
                "championStat_keyCS2": 3,
                "championStat_keyCS3": 4,
                "damageStat_keyDS1": 2,
                "damageStat_keyDS2": 2,
                "damageStat_keyDS3": 1,
            },
            4: {
                "key1": 5,
                "key2": 3,
                "key3": 4,
                "position": (11, 25),
                "championStat_keyCS1": 4,
                "championStat_keyCS2": 1,
                "championStat_keyCS3": 3,
                "damageStat_keyDS1": 1,
                "damageStat_keyDS2": 3,
                "damageStat_keyDS3": 4,
            },
            5: {
                "key1": 3,
                "key2": 6,
                "key3": 1,
                "position": (34, 54),
                "championStat_keyCS1": 5,
                "championStat_keyCS2": 5,
                "championStat_keyCS3": 3,
                "damageStat_keyDS1": 8,
                "damageStat_keyDS2": 4,
                "damageStat_keyDS3": 5,
            },
            6: {
                "key1": 0,
                "key2": 1,
                "key3": 3,
                "position": (76, 56),
                "championStat_keyCS1": 4,
                "championStat_keyCS2": 2,
                "championStat_keyCS3": 3,
                "damageStat_keyDS1": 4,
                "damageStat_keyDS2": 5,
                "damageStat_keyDS3": 1,
            },
            7: {
                "key1": 1,
                "key2": 2,
                "key3": 1,
                "position": (23, 32),
                "championStat_keyCS1": 5,
                "championStat_keyCS2": 1,
                "championStat_keyCS3": 3,
                "damageStat_keyDS1": 4,
                "damageStat_keyDS2": 5,
                "damageStat_keyDS3": 1,
            },
            8: {
                "key1": 7,
                "key2": 6,
                "key3": 8,
                "position": (31, 12),
                "championStat_keyCS1": 0,
                "championStat_keyCS2": 3,
                "championStat_keyCS3": 1,
                "damageStat_keyDS1": 1,
                "damageStat_keyDS2": 0,
                "damageStat_keyDS3": 2,
            },
            9: {
                "key1": 8,
                "key2": 9,
                "key3": 0,
                "position": (11, 8),
                "championStat_keyCS1": 4,
                "championStat_keyCS2": 1,
                "championStat_keyCS3": 3,
                "damageStat_keyDS1": 1,
                "damageStat_keyDS2": 3,
                "damageStat_keyDS3": 2,
            },
            10: {
                "key1": 0,
                "key2": 1,
                "key3": 2,
                "position": (15, 21),
                "championStat_keyCS1": 4,
                "championStat_keyCS2": 1,
                "championStat_keyCS3": 3,
                "damageStat_keyDS1": 2,
                "damageStat_keyDS2": 6,
                "damageStat_keyDS3": 9,
            },
        }

        # Call the function
        result = process_participant_frames(data)
        # Assert the result
        self.assertEqual(result, expected_result)

    def test_reduce_summary_damage(self) -> None:
        """Test summary_damage function."""
        # Test data
        data = [
            {
                "basic": True,
                "magicDamage": 0,
                "name": "Kaisa",
                "participantId": 4,
                "physicalDamage": 61,
                "spellName": "",
                "spellSlot": 63,
                "trueDamage": 0,
                "type": "OTHER",
            },
            {
                "basic": False,
                "magicDamage": 98,
                "name": "Kaisa",
                "participantId": 4,
                "physicalDamage": 0,
                "spellName": "kaisapassive",
                "spellSlot": 63,
                "trueDamage": 0,
                "type": "OTHER",
            },
            {
                "basic": True,
                "magicDamage": 0,
                "name": "Kaisa",
                "participantId": 5,
                "physicalDamage": 61,
                "spellName": "kaisabasicattack2",
                "spellSlot": 65,
                "trueDamage": 0,
                "type": "OTHER",
            },
            {
                "basic": True,
                "magicDamage": 0,
                "name": "Kaisa",
                "participantId": 7,
                "physicalDamage": 61,
                "spellName": "kaisabasicattack",
                "spellSlot": 64,
                "trueDamage": 0,
                "type": "OTHER",
            },
            {
                "basic": True,
                "magicDamage": 0,
                "name": "Kaisa",
                "participantId": 4,
                "physicalDamage": 61,
                "spellName": "kaisabasicattack3",
                "spellSlot": 66,
                "trueDamage": 0,
                "type": "OTHER",
            },
            {
                "basic": False,
                "magicDamage": 0,
                "name": "Kaisa",
                "participantId": 4,
                "physicalDamage": 86,
                "spellName": "kaisaq",
                "spellSlot": 0,
                "trueDamage": 0,
                "type": "OTHER",
            },
            {
                "basic": False,
                "magicDamage": 88,
                "name": "Pyke",
                "participantId": 5,
                "physicalDamage": 0,
                "spellName": "pykeq",
                "spellSlot": 0,
                "trueDamage": 0,
                "type": "OTHER",
            },
            {
                "basic": False,
                "magicDamage": 0,
                "name": "Pyke",
                "participantId": 5,
                "physicalDamage": 0,
                "spellName": "pykee",
                "spellSlot": 2,
                "trueDamage": 91,
                "type": "OTHER",
            },
            {
                "basic": False,
                "magicDamage": 0,
                "name": "Pyke",
                "participantId": 8,
                "physicalDamage": 0,
                "spellName": "summonerdot",
                "spellSlot": 4,
                "trueDamage": 18,
                "type": "OTHER",
            },
            {
                "basic": True,
                "magicDamage": 0,
                "name": "SRU_OrderMinionRanged",
                "participantId": 0,
                "physicalDamage": 19,
                "spellName": "sru_orderminionrangedbasicattack",
                "spellSlot": 64,
                "trueDamage": 0,
                "type": "MINION",
            },
        ]

        # Expected result
        expected_result = {
            "magicDamage": {
                4: 98,
                5: 88,
                7: 0,
                8: 0,
                0: 0,
            },
            "physicalDamage": {
                4: 208,
                5: 61,
                7: 61,
                8: 0,
                0: 19,
            },
            "trueDamage": {
                4: 0,
                5: 91,
                7: 0,
                8: 18,
                0: 0,
            },
        }

        # Call the function
        result = summary_damage(data)
        # Assert the result
        self.assertEqual(result, expected_result)

    def test_reduce_rehandle_events_1(self) -> None:
        """Test rehandle_events function."""
        # Test data
        data = {
            0: [
                {
                    "realTimestamp": 1712493653308,
                    "timestamp": 0,
                    "type": "PAUSE_END",
                    "eventOrd": 20,
                },
            ],
            1: [
                {
                    "type": "CHAMPION_KILL",
                    "bounty": 400,
                    "killerId": 9,
                    "victimDamageDealt": [
                        {
                            "magicDamage": 0,
                            "participantId": 5,
                            "physicalDamage": 86,
                            "spellSlot": 0,
                            "trueDamage": 0,
                        },
                        {
                            "magicDamage": 123,
                            "participantId": 7,
                            "physicalDamage": 0,
                            "spellSlot": 64,
                            "trueDamage": 0,
                        },
                    ],
                    "victimDamageReceived": [
                        {
                            "magicDamage": 0,
                            "participantId": 1,
                            "physicalDamage": 487,
                            "spellSlot": 63,
                            "trueDamage": 0,
                        },
                        {
                            "magicDamage": 0,
                            "participantId": 4,
                            "physicalDamage": 12,
                            "spellSlot": 1,
                            "trueDamage": 0,
                        },
                    ],
                    "eventOrd": 21,
                },
            ],
            2: [
                {
                    "type": "ELITE_MONSTER_KILL",
                    "assistingParticipantIds": [
                        6,
                        9,
                    ],
                    "killerId": 7,
                    "killerTeamId": 200,
                    "monsterType": "DRAGON",
                    "position": (10104, 4622),
                    "eventOrd": 22,
                },
                {
                    "type": "CHAMPION_KILL",
                    "assistingParticipantIds": [
                        2,
                        5,
                    ],
                    "bounty": 300,
                    "killerId": 3,
                    "position": (9517, 8879),
                    "victimDamageDealt": [
                        {
                            "magicDamage": 20,
                            "participantId": 0,
                            "physicalDamage": 0,
                            "spellSlot": -1,
                            "trueDamage": 0,
                        },
                        {
                            "magicDamage": 0,
                            "participantId": 2,
                            "physicalDamage": 97,
                            "spellSlot": 2,
                            "trueDamage": 0,
                        },
                    ],
                    "victimDamageReceived": [
                        {
                            "magicDamage": 0,
                            "participantId": 9,
                            "physicalDamage": 0,
                            "spellSlot": -1,
                            "trueDamage": 36,
                        },
                        {
                            "magicDamage": 0,
                            "participantId": 6,
                            "physicalDamage": 86,
                            "spellSlot": 64,
                            "trueDamage": 0,
                        },
                    ],
                    "eventOrd": 25,
                },
            ],
            3: [
                {
                    "type": "BUILDING_KILL",
                    "assistingParticipantIds": [
                        6,
                    ],
                    "buildingType": "TOWER_BUILDING",
                    "towerType": "NEXUS_TURRET",
                    "eventOrd": 26,
                },
            ],
            4: [
                {
                    "type": "ELITE_MONSTER_KILL",
                    "killerId": 2,
                    "killerTeamId": 100,
                    "monsterType": "HORDE",
                    "position": (4790, 10182),
                    "eventOrd": 30,
                },
                {
                    "type": "CHAMPION_SPECIAL_KILL",
                    "killType": "KILL_MULTI",
                    "multiKillLength": 2,
                    "eventOrd": 21,
                },
                {
                    "type": "BUILDING_KILL",
                    "buildingType": "INHIBITOR_BUILDING",
                    "position": (3454, 1241),
                    "eventOrd": 32,
                },
            ],
            5: [
                {
                    "type": "CHAMPION_SPECIAL_KILL",
                    "killType": "KILL_FIRST_BLOOD",
                    "position": (9955, 6139),
                    "eventOrd": 25,
                },
            ],
            6: [
                {
                    "type": "LEVEL_UP",
                    "participantId": 6,
                    "eventOrd": 34,
                },
            ],
        }

        # Expected result
        expected_result_data = {
            "BUILDING_KILL": defaultdict(
                list,
                {
                    "assistingParticipantIds": [[6], []],
                    "buildingType": ["TOWER_BUILDING", "INHIBITOR_BUILDING"],
                    "towerType": ["NEXUS_TURRET", None],
                    "eventOrd": [26, 32],
                    "position": [None, (3454, 1241)],
                },
            ),
            "CHAMPION_KILL": defaultdict(
                list,
                {
                    "victimDamageReceived": {
                        "magicDamage": [{1: 0, 4: 0}, {9: 0, 6: 0}],
                        "physicalDamage": [{1: 487, 4: 12}, {9: 0, 6: 86}],
                        "trueDamage": [{1: 0, 4: 0}, {9: 36, 6: 0}],
                    },
                    "victimDamageDealt": {
                        "magicDamage": [{5: 0, 7: 123}, {0: 20, 2: 0}],
                        "physicalDamage": [{5: 86, 7: 0}, {0: 0, 2: 97}],
                        "trueDamage": [{5: 0, 7: 0}, {0: 0, 2: 0}],
                    },
                    "bounty": [400, 300],
                    "killerId": [9, 3],
                    "eventOrd": [21, 25],
                    "assistingParticipantIds": [[], [2, 5]],
                    "position": [None, (9517, 8879)],
                    "timestamp": [],
                },
            ),
            "ELITE_MONSTER_KILL": defaultdict(
                list,
                {
                    "assistingParticipantIds": [[6, 9], []],
                    "killerId": [7, 2],
                    "killerTeamId": [200, 100],
                    "monsterType": ["DRAGON", "HORDE"],
                    "position": [(10104, 4622), (4790, 10182)],
                    "eventOrd": [22, 30],
                },
            ),
            "LEVEL_UP": defaultdict(list, {"participantId": [6], "eventOrd": [34]}),
            "PAUSE_END": defaultdict(
                list,
                {"realTimestamp": [1712493653308], "timestamp": [0], "eventOrd": [20]},
            ),
        }

        expected_linked_result = {
            "CHAMPION_SPECIAL_KILL": defaultdict(
                list,
                {
                    "killType": ["KILL_MULTI", "KILL_FIRST_BLOOD"],
                    "multiKillLength": [2],
                    "eventOrd": [21, 25],
                    "position": [(9955, 6139)],
                    "timestamp": [],
                },
            ),
        }

        expected_result_damagedealt_damagereceived = {
            21: {
                "victimDamageDealt": [
                    {
                        "magicDamage": 0,
                        "participantId": 5,
                        "physicalDamage": 86,
                        "spellSlot": 0,
                        "trueDamage": 0,
                    },
                    {
                        "magicDamage": 123,
                        "participantId": 7,
                        "physicalDamage": 0,
                        "spellSlot": 64,
                        "trueDamage": 0,
                    },
                ],
                "victimDamageReceived": [
                    {
                        "magicDamage": 0,
                        "participantId": 1,
                        "physicalDamage": 487,
                        "spellSlot": 63,
                        "trueDamage": 0,
                    },
                    {
                        "magicDamage": 0,
                        "participantId": 4,
                        "physicalDamage": 12,
                        "spellSlot": 1,
                        "trueDamage": 0,
                    },
                ],
            },
            25: {
                "victimDamageDealt": [
                    {
                        "magicDamage": 20,
                        "participantId": 0,
                        "physicalDamage": 0,
                        "spellSlot": -1,
                        "trueDamage": 0,
                    },
                    {
                        "magicDamage": 0,
                        "participantId": 2,
                        "physicalDamage": 97,
                        "spellSlot": 2,
                        "trueDamage": 0,
                    },
                ],
                "victimDamageReceived": [
                    {
                        "magicDamage": 0,
                        "participantId": 9,
                        "physicalDamage": 0,
                        "spellSlot": -1,
                        "trueDamage": 36,
                    },
                    {
                        "magicDamage": 0,
                        "participantId": 6,
                        "physicalDamage": 86,
                        "spellSlot": 64,
                        "trueDamage": 0,
                    },
                ],
            },
        }

        result_data, linked_result, result_damagedealt_damagereceived = rehandle_events(
            data,
        )

        self.assertDictEqual(result_data, expected_result_data)
        self.assertDictEqual(linked_result, expected_linked_result)
        self.assertDictEqual(
            result_damagedealt_damagereceived,
            expected_result_damagedealt_damagereceived,
        )

    def test_returns_dictionary_with_assisting_participant_ids(self) -> None:
        """Test rehandle_events function."""
        # Arrange
        events_per_minutes = {
            1: [
                {"type": "CHAMPION_KILL", "eventOrd": 1},
                {"type": "CHAMPION_SPECIAL_KILL", "eventOrd": 1},
                {"type": "CHAMPION_KILL", "eventOrd": 2},
                {"type": "CHAMPION_SPECIAL_KILL", "eventOrd": 2},
                {"type": "BUILDING_KILL", "eventOrd": 3},
                {"type": "BUILDING_KILL", "eventOrd": 4},
            ],
            2: [
                {"type": "ELITE_MONSTER_KILL", "eventOrd": 5},
                {"type": "ELITE_MONSTER_KILL", "eventOrd": 6},
            ],
        }

        expected_result = {
            "BUILDING_KILL": defaultdict(
                list,
                {
                    "eventOrd": [3, 4],
                    "assistingParticipantIds": [[], []],
                },
            ),
            "CHAMPION_KILL": defaultdict(
                list,
                {
                    "victimDamageReceived": {
                        "magicDamage": [{}, {}],
                        "physicalDamage": [{}, {}],
                        "trueDamage": [{}, {}],
                    },
                    "victimDamageDealt": {
                        "magicDamage": [{}, {}],
                        "physicalDamage": [{}, {}],
                        "trueDamage": [{}, {}],
                    },
                    "eventOrd": [1, 2],
                    "assistingParticipantIds": [[], []],
                    "timestamp": [],
                },
            ),
            "ELITE_MONSTER_KILL": defaultdict(
                list,
                {
                    "eventOrd": [5, 6],
                    "assistingParticipantIds": [[], []],
                },
            ),
        }

        expected_linked_result = {
            "CHAMPION_SPECIAL_KILL": defaultdict(
                list,
                {
                    "eventOrd": [1, 2],
                    "timestamp": [],
                },
            ),
        }

        expected_damage = {
            1: {
                "victimDamageDealt": [],
                "victimDamageReceived": [],
            },
            2: {
                "victimDamageDealt": [],
                "victimDamageReceived": [],
            },
        }

        # Act
        result, linked_result, result_damage = rehandle_events(events_per_minutes)
        # Assert the result
        self.assertDictEqual(result, expected_result)
        self.assertDictEqual(linked_result, expected_linked_result)
        self.assertDictEqual(result_damage, expected_damage)

    def test_reduce_rehandle_events_2(self) -> None:
        """Test rehandle_events function."""
        # Test data
        data = {
            1: [
                {
                    "level": 3,
                    "participantId": 5,
                    "timestamp": 229447,
                    "type": "LEVEL_UP",
                },
                {
                    "levelUpType": "NORMAL",
                    "participantId": 5,
                    "skillSlot": 3,
                    "timestamp": 230580,
                    "type": "SKILL_LEVEL_UP",
                },
                {
                    "assistingParticipantIds": [
                        5,
                    ],
                    "bounty": 300,
                    "killStreakLength": 1,
                    "killerId": 4,
                    "position": (13928, 3744),
                    "timestamp": 236030,
                    "type": "CHAMPION_KILL",
                    "victimDamageDealt": [
                        {
                            "basic": True,
                            "magicDamage": 0,
                            "participantId": 5,
                            "physicalDamage": 396,
                            "trueDamage": 0,
                        },
                    ],
                    "victimDamageReceived": [
                        {
                            "basic": True,
                            "magicDamage": 0,
                            "participantId": 4,
                            "physicalDamage": 195,
                            "trueDamage": 0,
                        },
                        {
                            "basic": False,
                            "magicDamage": 0,
                            "participantId": 4,
                            "physicalDamage": 0,
                            "trueDamage": 13,
                        },
                        {
                            "basic": False,
                            "magicDamage": 0,
                            "participantId": 4,
                            "physicalDamage": 50,
                            "trueDamage": 0,
                        },
                        {
                            "basic": False,
                            "magicDamage": 53,
                            "participantId": 5,
                            "physicalDamage": 0,
                            "trueDamage": 0,
                        },
                        {
                            "basic": True,
                            "magicDamage": 0,
                            "participantId": 5,
                            "physicalDamage": 119,
                            "trueDamage": 0,
                        },
                    ],
                    "eventOrd": 15,
                },
                {
                    "killType": "KILL_MULTI",
                    "killerId": 4,
                    "multiKillLength": 2,
                    "position": (13344, 3305),
                    "timestamp": 236030,
                    "type": "CHAMPION_SPECIAL_KILL",
                    "eventOrd": 15,
                },
            ],
            2: [
                {
                    "itemId": 2003,
                    "participantId": 2,
                    "timestamp": 250332,
                    "type": "ITEM_DESTROYED",
                },
                {
                    "assistingParticipantIds": [
                        7,
                    ],
                    "bounty": 300,
                    "killStreakLength": 0,
                    "killerId": 8,
                    "position": (7946, 7767),
                    "shutdownBounty": 0,
                    "timestamp": 250931,
                    "type": "CHAMPION_KILL",
                    "victimDamageReceived": [
                        {
                            "basic": True,
                            "magicDamage": 0,
                            "participantId": 0,
                            "physicalDamage": 427,
                            "trueDamage": 0,
                        },
                        {
                            "basic": False,
                            "magicDamage": 98,
                            "participantId": 8,
                            "physicalDamage": 0,
                            "trueDamage": 0,
                        },
                        {
                            "basic": True,
                            "magicDamage": 0,
                            "participantId": 5,
                            "physicalDamage": 19,
                            "trueDamage": 0,
                        },
                        {
                            "basic": False,
                            "magicDamage": 0,
                            "participantId": 5,
                            "physicalDamage": 13,
                            "trueDamage": 0,
                        },
                    ],
                    "eventOrd": 31,
                },
                {
                    "level": 7,
                    "participantId": 2,
                    "timestamp": 254731,
                    "type": "LEVEL_UP",
                },
                {
                    "itemId": 2003,
                    "participantId": 6,
                    "timestamp": 256495,
                    "type": "ITEM_DESTROYED",
                },
                {
                    "killType": "KILL_FIRST_BLOOD",
                    "killerId": 9,
                    "position": (12664, 1788),
                    "timestamp": 177591,
                    "type": "CHAMPION_SPECIAL_KILL",
                },
            ],
        }

        # Expected results
        expected_result_data = {
            "CHAMPION_KILL": defaultdict(
                list,
                {
                    "victimDamageReceived": {
                        "magicDamage": [{4: 0, 5: 53}, {0: 0, 8: 98, 5: 0}],
                        "physicalDamage": [{4: 245, 5: 119}, {0: 427, 8: 0, 5: 32}],
                        "trueDamage": [{4: 13, 5: 0}, {0: 0, 8: 0, 5: 0}],
                    },
                    "victimDamageDealt": {
                        "magicDamage": [{5: 0}, {}],
                        "physicalDamage": [{5: 396}, {}],
                        "trueDamage": [{5: 0}, {}],
                    },
                    "assistingParticipantIds": [[5], [7]],
                    "bounty": [300, 300],
                    "killStreakLength": [1, 0],
                    "killerId": [4, 8],
                    "position": [(13928, 3744), (7946, 7767)],
                    "timestamp": [236030, 250931],
                    "eventOrd": [15, 31],
                    "shutdownBounty": [None, 0],
                },
            ),
            "ITEM_DESTROYED": defaultdict(
                list,
                {
                    "itemId": [2003, 2003],
                    "participantId": [2, 6],
                    "timestamp": [250332, 256495],
                },
            ),
            "LEVEL_UP": defaultdict(
                list,
                {
                    "level": [3, 7],
                    "participantId": [5, 2],
                    "timestamp": [229447, 254731],
                },
            ),
            "SKILL_LEVEL_UP": defaultdict(
                list,
                {
                    "levelUpType": ["NORMAL"],
                    "participantId": [5],
                    "skillSlot": [3],
                    "timestamp": [230580],
                },
            ),
        }

        expected_result_special_data = {
            "CHAMPION_SPECIAL_KILL": defaultdict(
                list,
                {
                    "killType": ["KILL_MULTI", "KILL_FIRST_BLOOD"],
                    "killerId": [4, 9],
                    "multiKillLength": [2],
                    "position": [(13344, 3305), (12664, 1788)],
                    "timestamp": [236030, 177591],
                    "eventOrd": [15],
                },
            ),
        }

        expected_result_damagedealt_damagereceived = {
            15: {
                "victimDamageDealt": [
                    {
                        "basic": True,
                        "magicDamage": 0,
                        "participantId": 5,
                        "physicalDamage": 396,
                        "trueDamage": 0,
                    },
                ],
                "victimDamageReceived": [
                    {
                        "basic": True,
                        "magicDamage": 0,
                        "participantId": 4,
                        "physicalDamage": 195,
                        "trueDamage": 0,
                    },
                    {
                        "basic": False,
                        "magicDamage": 0,
                        "participantId": 4,
                        "physicalDamage": 0,
                        "trueDamage": 13,
                    },
                    {
                        "basic": False,
                        "magicDamage": 0,
                        "participantId": 4,
                        "physicalDamage": 50,
                        "trueDamage": 0,
                    },
                    {
                        "basic": False,
                        "magicDamage": 53,
                        "participantId": 5,
                        "physicalDamage": 0,
                        "trueDamage": 0,
                    },
                    {
                        "basic": True,
                        "magicDamage": 0,
                        "participantId": 5,
                        "physicalDamage": 119,
                        "trueDamage": 0,
                    },
                ],
            },
            31: {
                "victimDamageDealt": [],
                "victimDamageReceived": [
                    {
                        "basic": True,
                        "magicDamage": 0,
                        "participantId": 0,
                        "physicalDamage": 427,
                        "trueDamage": 0,
                    },
                    {
                        "basic": False,
                        "magicDamage": 98,
                        "participantId": 8,
                        "physicalDamage": 0,
                        "trueDamage": 0,
                    },
                    {
                        "basic": True,
                        "magicDamage": 0,
                        "participantId": 5,
                        "physicalDamage": 19,
                        "trueDamage": 0,
                    },
                    {
                        "basic": False,
                        "magicDamage": 0,
                        "participantId": 5,
                        "physicalDamage": 13,
                        "trueDamage": 0,
                    },
                ],
            },
        }

        # Call the function
        result_data, result_special_data, result_damagedealt_damagereceived = (
            rehandle_events(data)
        )

        # Assert the result
        self.assertDictEqual(result_data, expected_result_data)
        self.assertDictEqual(result_special_data, expected_result_special_data)
        self.assertDictEqual(
            result_damagedealt_damagereceived,
            expected_result_damagedealt_damagereceived,
        )


if __name__ == "__main__":
    unittest.main()
