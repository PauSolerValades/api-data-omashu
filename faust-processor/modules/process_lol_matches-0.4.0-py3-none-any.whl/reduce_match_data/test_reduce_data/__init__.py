"""Test package for reduce_data."""
