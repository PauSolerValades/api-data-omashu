"""Tests the functions from reduce_postmatch.py."""

import json
import sys
import unittest
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from reduce_data.reduce_postmatch import (
    player_to_team,
    process_bans,
    process_build,
    process_gamedata,
    process_postmatch,
    reduce_postmatch_data,
    reduce_postmatch_team_data,
)


def convert_keys(obj: dict | list | str) -> dict:
    """Convert the data read from a JSON to a dictionary converting the keys that are digits to integers.

    Args:
    ----
        obj (dict | list | str): The object to convert.

    Returns:
    -------
        dict: The object with the keys converted to integers.

    """
    if isinstance(obj, dict):
        new_obj = {}
        for k, v in obj.items():
            new_key = int(k) if k.isdigit() else k  # Convert keys that are digits
            new_obj[new_key] = convert_keys(v)  # Recurse into nested dictionaries
        return new_obj
    elif isinstance(obj, list):  # noqa: RET505
        return [convert_keys(item) for item in obj]  # Recurse into lists
    else:
        return None if obj == "None" else obj


class TestReducePostmatchData(unittest.TestCase):
    """Tests the functions in reduce_postmatch.py."""

    def test_ok_reduce_postmatch_data(self) -> None:
        """Test the behavior of reduce_postmatch_data with valid input."""
        data = {
            1: {"metric1": 10, "metric2": 20},
            2: {"metric1": 30, "metric2": 40},
            3: {"metric1": 50, "metric2": 60},
        }

        expected_result = {
            "metric1": {1: 10, 2: 30, 3: 50},
            "metric2": {1: 20, 2: 40, 3: 60},
        }

        result = reduce_postmatch_data(data)
        self.assertEqual(result, expected_result)

    def test_process_gamedata(self) -> None:
        """Tests the behaviour of process_gamedata with a valid input.

        The test contains variables included in resources.player_keys,
        resources.team_keys and resources.to_info_keys, which will be classified
        into the corresponding dictionaries. It also contains a variable that is
        not included in any of the dictionaries, which will be classified into the
        unclassified_data dictionary.
        """
        participant_data = {
            "challenges": {
                "12AssistStreakCount": 5,
                "killsOnLanersEarlyJungleAsJungler": 3,
            },
            "missions": {
                "missionsPlayerScore0": 10,
                "missionsPlayerScore1": 20,
            },
            "assists": 15,
            "kills": 10,
            "deaths": 5,
            "gameLength": 2000,
            "gameEndedInSurrender": False,
            "gameEndedInEarlySurrender": False,
            "superNewVariablePlayer": 19347,
        }

        objective_data = {
            "baron": {
                "kills": 2,
                "time": 1500,
            },
            "dragon": {
                "kills": 3,
                "time": 2000,
            },
        }

        (
            combined_players_data,
            combined_teams_data,
            player_challenges,
            team_challenges,
            unclassified_data,
            to_info,
        ) = process_gamedata(participant_data, objective_data)

        expected_players_data = {
            "assists": 15,
            "kills": 10,
            "deaths": 5,
            "missionsPlayerScore0": 10,
            "missionsPlayerScore1": 20,
        }

        expected_teams_data = {
            "teamKillsBaron": 2,
            "teamKillsDragon": 3,
            "teamTimeBaron": 1500,
            "teamTimeDragon": 2000,
        }

        expected_player_challeges = {
            "12AssistStreakCount": 5,
            "killsOnLanersEarlyJungleAsJungler": 3,
        }

        expected_team_challenges = {}

        expected_to_info_data = {
            "gameLength": 2000,
            "gameEndedInSurrender": False,
            "gameEndedInEarlySurrender": False,
        }

        expected_unclassified_data = {"superNewVariablePlayer": 19347}

        self.assertEqual(combined_players_data, expected_players_data)
        self.assertEqual(combined_teams_data, expected_teams_data)
        self.assertEqual(player_challenges, expected_player_challeges)
        self.assertEqual(team_challenges, expected_team_challenges)
        self.assertEqual(unclassified_data, expected_unclassified_data)
        self.assertEqual(to_info, expected_to_info_data)

    def test_process_bans(self) -> None:
        """Tests the behaviour of process_bans with a reduced but properly formatted input.

        The test contains two teams with two bans each, and a dictionary with the player's champions.
        """
        teams = [
            {
                "bans": [
                    {"pickTurn": 1, "championId": 1},
                    {"pickTurn": 2, "championId": 2},
                ],
            },
            {
                "bans": [
                    {"pickTurn": 1, "championId": 3},
                    {"pickTurn": 2, "championId": 4},
                ],
            },
        ]

        player_champions = {
            1: {
                "participantId": 1,
                "championId": 1,
                "championName": "Champion1",
                "teamId": 1,
            },
            2: {
                "participantId": 2,
                "championId": 2,
                "championName": "Champion2",
                "teamId": 1,
            },
            3: {
                "participantId": 3,
                "championId": 3,
                "championName": "Champion3",
                "teamId": 2,
            },
            4: {
                "participantId": 4,
                "championId": 4,
                "championName": "Champion4",
                "teamId": 2,
            },
        }

        expected_result = {
            1: {
                "pickTurnBanned": 1,
                "championIdBanned": 3,
                "championId": 1,
                "championName": "Champion1",
                "teamId": 1,
            },
            2: {
                "pickTurnBanned": 2,
                "championIdBanned": 4,
                "championId": 2,
                "championName": "Champion2",
                "teamId": 1,
            },
        }

        result = process_bans(teams, player_champions)

        self.assertEqual(result, expected_result)

    def test_process_bans_2(self) -> None:
        """Tests the same behaviour as the previous test, but with different input values."""
        teams = [
            {
                "bans": [
                    {"pickTurn": 1, "championId": 1},
                    {"pickTurn": 2, "championId": 2},
                ],
            },
            {
                "bans": [
                    {"pickTurn": 6, "championId": 3},
                    {"pickTurn": 7, "championId": 4},
                ],
            },
        ]
        player_champions = {
            1: {
                "participantId": 1,
                "championId": 1,
                "championName": "Champion1",
                "teamId": 1,
            },
            2: {
                "participantId": 2,
                "championId": 2,
                "championName": "Champion2",
                "teamId": 1,
            },
            6: {
                "participantId": 6,
                "championId": 3,
                "championName": "Champion3",
                "teamId": 2,
            },
            7: {
                "participantId": 7,
                "championId": 4,
                "championName": "Champion4",
                "teamId": 2,
            },
        }
        expected_result = {
            1: {
                "pickTurnBanned": 1,
                "championIdBanned": 1,
                "championId": 1,
                "championName": "Champion1",
                "teamId": 1,
            },
            2: {
                "pickTurnBanned": 2,
                "championIdBanned": 2,
                "championId": 2,
                "championName": "Champion2",
                "teamId": 1,
            },
            6: {
                "pickTurnBanned": 6,
                "championIdBanned": 3,
                "championId": 3,
                "championName": "Champion3",
                "teamId": 2,
            },
            7: {
                "pickTurnBanned": 7,
                "championIdBanned": 4,
                "championId": 4,
                "championName": "Champion4",
                "teamId": 2,
            },
        }

        result = process_bans(teams, player_champions)
        self.assertEqual(result, expected_result)

    def test_ok_process_build(self) -> None:
        """Tests happy path of process_build function with a reduced but properly formatted input."""
        player_info = {
            "participantId": 1,
            "championId": 123,
            "championName": "Ahri",
            "teamId": 1,
        }
        perks = {
            "statPerks": {"attackSpeed": 10, "adaptiveForce": 20, "armor": 30},
            "styles": [{"selections": [{"key1": "value1", "key2": "value2"}]}],
        }
        items = {
            "item1": "item1_value",
            "item2": "item2_value",
            "legendaryItemsUsed": ["item3", "item4"],
        }
        summoner = {
            "summoner1": "summoner1_value",
            "summoner2": "summoner2_value",
        }
        team_position = "top"

        expected_result = {
            "teamPosition": "top",
            "legendaryItemsUsed": ["item3", "item4"],
            "summoner1": "summoner1_value",
            "summoner2": "summoner2_value",
            "participantId": 1,
            "championId": 123,
            "championName": "Ahri",
            "teamId": 1,
            "statPerksAttackspeed": 10,
            "statPerksAdaptiveforce": 20,
            "statPerksArmor": 30,
            "stylesSelections00Key1": "value1",
            "stylesSelections00Key2": "value2",
            "item1": "item1_value",
            "item2": "item2_value",
        }

        result = process_build(
            player_info,
            perks,
            items,
            summoner,
            team_position,
        )
        self.assertEqual(result, expected_result)

    def test_ok_reduce_postmatch_team_data(self) -> None:
        """Tests the behaviour of reduce_postmatch_team_data with a reduced properly formatted input.

        It will group together the variables of the same name and return a dictionary with the reduced data.
        It WON'T check if the data has the same value for all players, as it is not the purpose of this function.
        """
        data_players = {
            1: {"metric1": 10, "metric2": 100, "metric3": 1000},
            2: {"metric1": 10, "metric2": 100, "metric3": 1000},
            3: {"metric1": 10, "metric2": 100, "metric3": 1000},
            4: {"metric1": 10, "metric2": 100, "metric3": 1000},
            5: {"metric1": 10, "metric2": 100, "metric3": 1000},
            6: {"metric1": 60, "metric2": 600, "metric3": 6000},
            7: {"metric1": 60, "metric2": 600, "metric3": 6000},
            8: {"metric1": 60, "metric2": 600, "metric3": 6000},
            9: {"metric1": 60, "metric2": 600, "metric3": 6000},
            10: {"metric1": 60, "metric2": 600, "metric3": 6000},
        }

        expected_result = {
            "metric1": {
                "100": 10,
                "200": 60,
            },
            "metric2": {
                "100": 100,
                "200": 600,
            },
            "metric3": {
                "100": 1000,
                "200": 6000,
            },
        }

        # if the input is a dictionary with player data, it returns the reduced data for the teams
        result = reduce_postmatch_team_data(data_players)
        self.assertEqual(result, expected_result)

        data_teams = {
            "100": {"metric1": 10, "metric2": 100, "metric3": 1000},
            "200": {"metric1": 60, "metric2": 600, "metric3": 6000},
        }

        # if the input is a dictionary with team data, it returns the same data
        result_2 = reduce_postmatch_team_data(data_teams)
        self.assertEqual(result_2, expected_result)

        # Should correctly reduce the data for a postmatch with 2 teams and multiple challenge metrics

    def test_ok_reduce_postmatch_team_challenges(self) -> None:
        """Tests the behaviour of reduce_postmatch_team_data with a reduced properly formatted input."""
        # Arrange
        data = {
            "100": {"metric1": 80, "metric2": 800, "metric3": 8000},
            "200": {"metric1": 30, "metric2": 300, "metric3": 3000},
        }

        expected_result = {
            "metric1": {
                "100": 80,
                "200": 30,
            },
            "metric2": {
                "100": 800,
                "200": 300,
            },
            "metric3": {
                "100": 8000,
                "200": 3000,
            },
        }

        result = reduce_postmatch_team_data(data)
        self.assertEqual(result, expected_result)

    def test_player_to_team(self) -> None:
        """Tests the player_to_team function with different inputs."""
        test_cases = [
            (5, "100"),
            (0, None),
            (7, "200"),
            (10, "200"),
        ]
        for player, expected_result in test_cases:
            result = player_to_team(player)
            self.assertEqual(result, expected_result)

    def test_ok_process_postmatch(self) -> None:
        """Tests the process_postmatch function with real data loaded from the json files."""
        with Path.open("./reduce_data/Tests/test_data/input/ok_postmatch.json") as file:
            match = dict(json.load(file))
        with Path.open(
            "./reduce_data/Tests/test_data/expected/ok_postmatch.json",
        ) as file:
            expected_result = json.load(file)
        expected_result = convert_keys(expected_result)
        result = process_postmatch(match)
        self.assertEqual(result, expected_result)

    def test_process_postmatch_without_some_variables(self) -> None:
        """Tests the process_postmatch function with real data loaded from the json files, but with some variables missing.

        Specifically:
        - participantId 1 is missing the summonerId and item4 variables.
        - participantId 6 is missing the legendaryItemUsed variable.
        """
        with Path.open(
            "./reduce_data/Tests/test_data/input/process_postmatch_without_some_variables.json",
        ) as file:
            match = dict(json.load(file))
        with Path.open(
            "./reduce_data/Tests/test_data/expected/process_postmatch_without_some_variables.json",
        ) as file:
            expected_result = json.load(file)

        expected_result = convert_keys(expected_result)

        result = process_postmatch(match)
        self.assertEqual(result, expected_result)

    def test_process_postmatch_without_bans(self) -> None:
        """Tests the process_postmatch function with real data loaded from the json files, but with the bans key missing.

        This is a common scenario with all the matches that are not 420 nor ranked.
        The expected result is the same as the input, as the function should not modify the data if the bans key is missing.
        """
        with Path.open(
            "./reduce_data/Tests/test_data/input/process_postmatch_without_bans.json",
        ) as file:
            match = dict(json.load(file))
        with Path.open(
            "./reduce_data/Tests/test_data/expected/process_postmatch_without_bans.json",
        ) as file:
            expected_result = json.load(file)

        expected_result = convert_keys(expected_result)

        result = process_postmatch(match)
        self.assertEqual(result, expected_result)


if __name__ == "__main__":
    unittest.main()
