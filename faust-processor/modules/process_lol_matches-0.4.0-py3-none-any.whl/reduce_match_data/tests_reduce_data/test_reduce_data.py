"""Test reduce data functions."""

import sys
import unittest
from pathlib import Path

sys.path.append(Path(__file__).resolve().parent.parent)

from reduce_match_data.sort_pid_pos import team_position_to_participant_id


class TestReduceBytimeParticipants(unittest.TestCase):
    """Test class for reduce_bytime_participants.py."""

    def test_team_position_to_participant_id(self) -> None:
        """Test team position to participant id function."""
        wrong_team_position = {
            1: "JUNGLE",
            2: "",
            3: "MIDDLE",
            4: "BOTTOM",
            5: "UTILITY",
            6: "UTILITY",
            7: "TOP",
            8: "BOTTOM",
            9: "",
            10: "",
        }
        team_position, position_shuffled = team_position_to_participant_id(
            wrong_team_position,
        )

        expected_team_position = {
            1: "JUNGLE",
            2: "TOP",
            3: "MIDDLE",
            4: "BOTTOM",
            5: "UTILITY",
            6: "UTILITY",
            7: "TOP",
            8: "BOTTOM",
            9: "JUNGLE",
            10: "MIDDLE",
        }
        expected_position_shuffle = True

        self.assertEqual(team_position, expected_team_position)
        self.assertEqual(position_shuffled, expected_position_shuffle)
