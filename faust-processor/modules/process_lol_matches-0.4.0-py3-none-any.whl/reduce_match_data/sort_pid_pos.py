"""Functions to exchange the participantId from the default participantId assigned to it's teamPosition equivalent."""

from .resources import PARTICIPANTS_100, PARTICIPANTS_200, TEAM_ID_100, TEAM_ID_200


def team_position_to_participant_id(gamedata_team_position: dict) -> tuple[dict, dict]:
    """Reorder participantId adapting to teamPosition metric, making them equal.

    Args:
    ----
        gamedata_team_position (dict): participant id team position metric from postmatch.

    Returns:
    -------
        tuple[dict, dict]: participant team position and shuffled team positions bool.

    """
    team_position_id = {participant_id: str for participant_id in range(1, 11)}
    team_100_positions, team_100_shuffled = fill_missing_team_position(
        gamedata_team_position,
        PARTICIPANTS_100,
    )
    team_200_positions, team_200_shuffled = fill_missing_team_position(
        gamedata_team_position,
        PARTICIPANTS_200,
    )
    team_position_id = dict(
        enumerate(
            team_100_positions + team_200_positions,
            start=1,
        ),
    )

    positions_shuffled = bool(team_100_shuffled + team_200_shuffled)
    return team_position_id, positions_shuffled


def fill_missing_team_position(
    team_position: dict,
    participant_ids: list[int],
) -> list[str]:
    """Find missing team positions in the team and fill the blanks, keeping the previously known positions.

    In case more than one position is missing, means that RIOT can't know the exact positions of all of the players.
    In that case, we use the correspondant participantId in the missing positions.
    EG:
    ["TOP", "MID", "","", "JUNGLE"] -> ["TOP", "MID", "BOTTOM", "UTILITY", "JUNGLE"]

    Args:
    ----
        team_position (dict): participant id team position metric from postmatch
        participant_ids (list[int]): participant ids to process (from team 100 or team 200)

    Returns:
    -------
        list[str]: like ["TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY"]


    """
    expected_team_positions = ["TOP", "JUNGLE", "MIDDLE", "BOTTOM", "UTILITY"]

    team_positions = [
        team_position[player_id]
        for player_id in team_position
        if player_id in participant_ids
    ]
    # Find positions with a "", the ones not know in the data
    missing_team_positions = [
        position
        for position in expected_team_positions
        if position not in team_positions
    ]
    if len(missing_team_positions) > 1:
        # If more than one missing positions found
        current_missing_position = 0
        for i, position in enumerate(team_positions):
            if position == "":
                # Fill the blanks in order
                team_positions[i] = missing_team_positions[current_missing_position]
                current_missing_position += 1
    else:
        # If one or less missing positions found
        for i, position in enumerate(team_positions):
            # Fill the missing position if necessary
            if position == "":
                team_positions[i] = missing_team_positions[0]

    return team_positions, team_positions != expected_team_positions


def player_to_team(player: int) -> str | None:
    """Convert participants ID to a team ID.

    Args:
    ----
        player (int): The participant ID.

    Returns:
    -------
        str | None: The team ID.

    """
    team_id = ""
    if int(player) in PARTICIPANTS_100:
        team_id = "100"
    elif int(player) in PARTICIPANTS_200:
        team_id = "200"
    elif int(player) == TEAM_ID_100:
        team_id = "100"
    elif int(player) == TEAM_ID_200:
        team_id = "200"
    else:
        team_id = None

    return team_id
