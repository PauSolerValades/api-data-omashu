"""Compute player, team and match stats."""
