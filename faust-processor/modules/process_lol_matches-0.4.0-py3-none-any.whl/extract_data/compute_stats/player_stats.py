"""Compute player stats."""

import logging

logger = logging.getLogger(__name__)

POSITION_PARTICIPANT_ID = {
    100: {"TOP": 1, "JUNGLE": 2, "MIDDLE": 3, "BOTTOM": 4, "UTILITY": 5},
    200: {"TOP": 6, "JUNGLE": 7, "MIDDLE": 8, "BOTTOM": 9, "UTILITY": 10},
}


def compute_player_stats(postmatch_new_metrics: dict) -> dict:
    """Extract player stats.

    Args:
    ----
        postmatch_new_metrics (dict): postmatch match data

    Returns:
    -------
        dict: {
            "metadata": {
                "matchId": str,
                "gameStart": int,
                "gameVersion": str,
                "gameDuration": int,
                "winningTeam": int
            },
            "player_stats": {
                puuid_1: {
                    "participantId": int,
                    "riotIdGameName": str,
                    "teamId": int,
                    "championId": int,
                    "itemsUsed": {},
                    "position": str,
                    "spiderMetrics": {
                        "kda": float,
                        "timeSpentLiving": int,
                        "visionScore": float,
                        "buildingKills": int,
                        "buildingKillsAssisted": int,
                        "eliteMonsterKills": int,
                        "eliteMonsterKillsAssisted": int,
                        "minionsKilled": int,
                        "minionsEfficency": float,
                        "jungleMonstersKilled": int,
                        "jungleMonstersEfficency": float,
                        "minionsConceeded": float,
                        "goldUsage": float,
                    },
                    "globalStats":{
                        "kills": int,
                        "deaths": int,
                        "assists": int,
                    },
                    "championPositionStats":{
                        "damageDealtToStructures": float,
                        "damageDealtToObjectives": float,
                        "damageDealtToChampions": float,
                    },
                ...,
                puuid_10: {...}
                }
            }
        }

    """
    player_metrics = postmatch_new_metrics["info"]["gamedata"]["players"]
    player_challenges = postmatch_new_metrics["info"]["gamedata"]["playerChallenges"]
    winning_team = postmatch_new_metrics["info"]["gamedata"]["teams"]["win"]
    stats = {
        "metadata": {
            "matchId": postmatch_new_metrics["metadata"]["matchId"],
            "gameStart": postmatch_new_metrics["info"]["gameStartTimestamp"],
            "gameVersion": postmatch_new_metrics["info"]["gameVersion"],
            "gameDuration": postmatch_new_metrics["info"]["gameDuration"],
            "queueId": postmatch_new_metrics["info"]["queueId"],
            "tournamentCode": postmatch_new_metrics["info"]["tournamentCode"],
            "winningTeam": 100 if winning_team["100"] is True else 200,
        },
        "player_stats": {},
    }
    for participant_id, puuid in player_metrics["puuid"].items():
        team_position = postmatch_new_metrics["metadata"]["teamPositionId"][
            participant_id
        ]
        participant_time_spent_living = 1 - (
            # time spent dead, per player
            player_metrics["totalTimeSpentDead"][participant_id]
            # game duration, all players have the same value
            / player_metrics["timePlayed"][participant_id]
        )
        stats["player_stats"][puuid] = {
            "participantId": POSITION_PARTICIPANT_ID[
                player_metrics["teamId"][participant_id]
            ][team_position],
            "riotIdGameName": player_metrics["riotIdGameName"][participant_id],
            "teamId": player_metrics["teamId"][participant_id],
            "championId": player_metrics["championId"][participant_id],
            "itemsUsed": player_metrics["itemsUsed"].get(participant_id, {}),
            "position": postmatch_new_metrics["metadata"]["teamPositionId"][
                participant_id
            ],
            "spiderMetrics": {
                "kda": round(player_challenges["kda"].get(participant_id, 0), 5),
                "timeSpentLiving": round(participant_time_spent_living, 5),
                "visionScore": player_metrics["visionScore"].get(participant_id, 0),
                "goldUsage": round(player_metrics["goldUsage"][participant_id], 5),
            },
            "globalStats": {
                "kills": round(
                    player_metrics["kills"].get(participant_id, 0),
                    5,
                ),
                "deaths": round(
                    player_metrics["deaths"].get(participant_id, 0),
                    5,
                ),
                "assists": round(
                    player_metrics["assists"].get(
                        participant_id,
                        0,
                    ),
                    5,
                ),
            },
            "championPositionStats": {
                "damageDealtToStructures": round(
                    player_metrics["damageDealtToBuildings"].get(participant_id, 0),
                    5,
                ),
                "damageDealtToObjectives": round(
                    player_metrics["damageDealtToObjectives"].get(participant_id, 0),
                    5,
                ),
                "damageDealtToChampions": round(
                    player_metrics["totalDamageDealtToChampions"].get(
                        participant_id,
                        0,
                    ),
                    5,
                ),
            },
        }
        spider_metrics = stats["player_stats"][puuid]["spiderMetrics"]
        if team_position in [
            "TOP",
            "MIDDLE",
            "BOTTOM",
        ]:
            spider_metrics["buildingKills"] = player_metrics.get(
                "buildingKill",
                {},
            ).get(participant_id, 0)

            spider_metrics["eliteMonsterKillsAssisted"] = player_metrics.get(
                "eliteMonsterAssist",
                {},
            ).get(
                participant_id,
                0,
            )
            spider_metrics["minionsEfficency"] = round(
                player_metrics["minionEfficency"][participant_id],
                5,
            )

        elif team_position == "JUNGLE":
            spider_metrics["buildingKillsAssisted"] = player_metrics.get(
                "buildingAssist",
                {},
            ).get(
                participant_id,
                0,
            )
            spider_metrics["eliteMonsterKills"] = player_metrics.get(
                "eliteMonsterKill",
                {},
            ).get(
                participant_id,
                0,
            )
            spider_metrics["jungleMonstersEfficency"] = round(
                player_metrics["jungleMonstersEfficency"][participant_id],
                5,
            )

        elif team_position == "UTILITY":
            spider_metrics["buildingKillsAssisted"] = player_metrics.get(
                "buildingAssist",
                {},
            ).get(
                participant_id,
                0,
            )
            spider_metrics["eliteMonsterKillsAssisted"] = player_metrics.get(
                "eliteMonsterAssist",
                {},
            ).get(
                participant_id,
                0,
            )
            spider_metrics["minionsConceeded"] = round(
                player_metrics.get("minionsConceeded", {}).get(
                    participant_id,
                    0,
                ),
                5,
            )
    return stats
