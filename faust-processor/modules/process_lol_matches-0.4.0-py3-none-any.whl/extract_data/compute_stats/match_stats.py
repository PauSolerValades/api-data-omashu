"""Compute match stats."""

import logging

import numpy as np
from scipy.interpolate import interp1d

logger = logging.getLogger(__name__)


def compute_match_stats(postmatch_new_metrics: dict, bytime_new_metrics: dict) -> dict:
    """Compute match stats.

    Args:
    ----
        postmatch_new_metrics (dict): postmatch metrics
        bytime_new_metrics (dict): bytime metrics

    Returns:
    -------
        dict: {
        "barMetrics": {
            100: {
                "totalDamageDealt": int,
                "championKills": int,
                "damageDeatlToBuildings": int,
                "buildingKills": int,
                "damageDeatlToEliteMonsters": int,
                "eliteMonsterKills": int,
                "totalGold": int,
                "legendaryItems": int,
            },
            200: {
                "totalDamageDealt": int,
                "championKills": int,
                "damageDeatlToBuildings": int,
                "buildingKills": int,
                "damageDeatlToEliteMonsters": int,
                "eliteMonsterKills": int,
                "totalGold": int,
                "legendaryItems": int,
            },
        },
        "timeLine": {
            "eventType": list[str],
            "killerId": list[int],
            "assistants": list[list[int]],
        },
        "goldGraph": {
            "players": {
                1: list[int],
                ...
                10: list[int]
            },
            "teams": {
                100: list[int],
                200: list[int]
            }

        },
    }

    """
    player_metrics = postmatch_new_metrics["info"]["gamedata"]["players"]
    team_metrics = postmatch_new_metrics["info"]["gamedata"]["teams"]
    player_legendary_items = postmatch_new_metrics["info"]["build"][
        "legendaryItemsUsed"
    ]
    total_gold = bytime_new_metrics["info"]["participantFrames"]["totalGold"]

    return {
        "timeLine": compute_time_line_events(postmatch_new_metrics, bytime_new_metrics),
        "goldGraph": {
            "players": {
                participant_id: list(
                    interpolate_metric(total_gold[participant_id]),
                )
                for participant_id in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
            },
        },
        "barsMetrics": compute_bar_metrics(
            player_metrics,
            team_metrics,
            player_legendary_items,
        ),
    }


def interpolate_metric(data: list[float]) -> list[float]:
    """Interpolate data using a point-to-point linear interpolation using 60 nodes per every interval.

    Args:
    ----
        data (list[float]): values to interpolate, length of the match minutes

    Returns:
    -------
        list[float]: interpolated values

    """
    x = np.arange(len(data))
    x_new = np.linspace(0, len(data) - 1, num=(len(data) - 1) * 6 + 1)

    linear_interpolator = interp1d(
        x,
        data,
        kind="linear",
        fill_value="extrapolate",
    )
    return linear_interpolator(x_new)


def compute_time_line_events(
    postmatch_new_metrics: dict,
    bytime_new_metrics: dict,
) -> dict:
    """Compute time line events from bytime.

    Args:
    ----
        postmatch_new_metrics (dict): postmatch data with new metrics
        bytime_new_metrics (dict): bytime data with new metrics

    Returns:
    -------
        dict: time line ordered by bytime events event order

    """
    skpiable_events = [
        "CHAMPION_SPECIAL_KILL",
        "GAME_END",
        "ITEM_UNDO",
        "ITEM_SOLD",
        "ITEM_DESTROYED",
        "ITEM_PURCHASED",
        "LEVEL_UP",
        "PAUSE_END",
        "SKILL_LEVEL_UP",
        "WARD_KILL",
        "WARD_PLACED",
    ]

    bytime_events = bytime_new_metrics["info"]["events"]
    linked_events = bytime_new_metrics["info"]["linkedEvents"]
    team_position = postmatch_new_metrics["metadata"]["teamPositionId"]
    all_events = {
        event_type: event_data
        for event_type, event_data in {**bytime_events, **linked_events}.items()
        if event_type not in skpiable_events
    }

    time_line = {}
    for event_type, event_data in all_events.items():
        if event_type != "SUPPORT_QUEST" and event_data:
            for current_event, event_ord in enumerate(event_data["eventOrd"]):
                time_line[event_ord] = {
                    "eventType": event_type,
                    "timestamp": event_data["timestamp"][current_event],
                }
                if "killerId" in event_data:
                    time_line[event_ord]["killerId"] = event_data["killerId"][
                        current_event
                    ]
                    time_line[event_ord]["objectiveId"] = event_objective_id(
                        event_data,
                        event_type,
                        current_event,
                        team_position,
                    )
                elif "teamId" in event_data:
                    time_line[event_ord]["teamId"] = event_data["teamId"][current_event]
                    if "name" in event_data:
                        time_line[event_ord]["dragonSoul"] = event_data["name"][
                            current_event
                        ]
                    elif "actualStartTime" in event_data:
                        time_line[event_ord]["startTimestamp"] = event_data[
                            "actualStartTime"
                        ][current_event]
                    else:
                        time_line[event_ord]["startTimestamp"] = event_data[
                            "timestamp"
                        ][current_event]
                elif "participantId" in event_data:
                    time_line[event_ord]["participantId"] = event_data["participantId"][
                        current_event
                    ]
        elif event_data:
            support_quest = support_quest_time_line(event_data, event_type)
            time_line.update(support_quest)
    return time_line


def support_quest_time_line(event_data: dict, event_type: str) -> dict:
    """Treat support quest, since it's the unique special event type.

    Args:
    ----
        event_data (dict): data of the SUPPORT QUEST bytime event
        event_type (str): SUPPORT QUEST

    Returns:
    -------
        dict: splited start and end of the support quest events

    """
    # Pendent de revisar coherencia de event orders
    time_line = {}
    for i in range(len(event_data["questCompleted"])):
        if event_data["startEventAssociated"][i]:
            time_line[event_data["startEventAssociated"][i]] = {
                "eventType": event_type,
                "participantId": event_data["participantId"][i],
            }
        if event_data["endEventAssociated"][i]:
            time_line[event_data["endEventAssociated"][i]] = {
                "eventType": event_type,
                "participantId": event_data["participantId"][i],
                "questCompleted": event_data["questCompleted"][i],
            }
    return time_line


def event_objective_id(
    event_data: dict,
    event_type: str,
    current_event_by_type: int,
    team_position: dict,
) -> str:
    """Name the objective of the event, if there is any target (enemy champion, elite monster or building)."""
    if (
        event_type in ["CHAMPION_KILL", "FIRST_BLOOD", "KILL_ACE"]
    ):  # ['victimDamageReceived', 'victimDamageDealt', 'assistingParticipantIds', 'bounty', 'killStreakLength', 'killerId', 'shutdownBounty', 'timestamp', 'victimId', 'position', 'eventOrd']
        objective = (
            f"ENEMY_{team_position[event_data['victimId'][current_event_by_type]]}"
        )
    elif (
        event_type == "ELITE_MONSTER_KILL"
    ):  # ['bounty', 'killerId', 'killerTeamId', 'monsterType', 'timestamp', 'position', 'eventOrd', 'assistingParticipantIds', 'monsterSubType']
        objective = (
            event_data["monsterSubType"][current_event_by_type]
            if event_data["monsterSubType"][current_event_by_type]
            else event_data["monsterType"][current_event_by_type]
        )
    elif (
        event_type == "BUILDING_KILL"
    ):  # ['assistingParticipantIds', 'bounty', 'buildingType', 'killerId', 'laneType', 'teamId', 'timestamp', 'towerType', 'position', 'eventOrd']
        objective = (
            (
                # NEXUS TURRET
                f"{event_data['towerType'][current_event_by_type]}"
                if event_data["towerType"][current_event_by_type] == "NEXUS_TURRET"
                # Any other TURRET
                else f"{event_data['laneType'][current_event_by_type]}_{event_data['towerType'][current_event_by_type]}"
            )
            if event_data["buildingType"][current_event_by_type] == "TOWER_BUILDING"
            # INHIBITORS
            else f"{event_data['laneType'][current_event_by_type]}_{event_data['buildingType'][current_event_by_type]}"
        )

    elif (
        event_type == "TURRET_PLATE_DESTROYED"
    ):  # ['killerId', 'laneType', 'teamId', 'timestamp', 'position', 'eventOrd']
        objective = f"{event_data['laneType'][current_event_by_type]}_TURRET_PLATE"
    elif event_type == "MULTI_KILL":
        objective = (
            f"ENEMY_{team_position[event_data['victimId'][current_event_by_type]]}"
        )
    return objective


def compute_bar_metrics(
    player_metrics: dict,
    team_metrics: dict,
    player_legendary_items: dict,
) -> dict:
    """Compute bar metrics.

    Args:
    ----
        player_metrics (dict): _description_
        team_metrics (dict): _description_
        player_legendary_items (dict): _description_

    Returns:
    -------
        dict: _description_

    """
    bar_metrics = {}
    sum_player_bar_metrics = {
        100: {
            "totalDamageDealt": sum(
                value
                for key, value in player_metrics["totalDamageDealt"].items()
                if int(key) in range(1, 6)
            ),
            "totalDamageDealtToChampions": sum(
                value
                for key, value in player_metrics["totalDamageDealtToChampions"].items()
                if int(key) in range(1, 6)
            ),
            "totalDamageDealtToEliteBuildings": sum(
                value
                for key, value in player_metrics["damageDealtToTurrets"].items()
                if int(key) in range(1, 6)
            ),
            "totalDamageDealtToEliteMonsters": sum(
                value
                for key, value in player_metrics["damageDealtToObjectives"].items()
                if int(key) in range(1, 6)
            ),
            "totalGold": sum(
                value
                for key, value in player_metrics["goldEarned"].items()
                if int(key) in range(1, 6)
            ),
            "legendaryItems": len(
                [
                    item
                    for participant_id, legendary_items in player_legendary_items.items()
                    for item in legendary_items
                    if int(participant_id) in range(1, 6)
                ],
            ),
        },
        200: {
            "totalDamageDealt": sum(
                value
                for key, value in player_metrics["totalDamageDealt"].items()
                if int(key) in range(6, 11)
            ),
            "totalDamageDealtToChampions": sum(
                value
                for key, value in player_metrics["totalDamageDealtToChampions"].items()
                if int(key) in range(6, 11)
            ),
            "totalDamageDealtToEliteBuildings": sum(
                value
                for key, value in player_metrics["damageDealtToTurrets"].items()
                if int(key) in range(6, 11)
            ),
            "totalDamageDealtToEliteMonsters": sum(
                value
                for key, value in player_metrics["damageDealtToObjectives"].items()
                if int(key) in range(6, 11)
            ),
            "totalGold": sum(
                value
                for key, value in player_metrics["goldEarned"].items()
                if int(key) in range(6, 11)
            ),
            "legendaryItems": len(
                [
                    item
                    for participant_id, legendary_items in player_legendary_items.items()
                    for item in legendary_items
                    if int(participant_id) in range(6, 11)
                ],
            ),
        },
    }

    for team_id in [100, 200]:
        bar_metrics[team_id] = {
            "totalDamageDealt": sum_player_bar_metrics[team_id]["totalDamageDealt"],
            "totalDamageDealtToChampions": sum_player_bar_metrics[team_id][
                "totalDamageDealtToChampions"
            ],
            "totalDamageDealtToEliteBuildings": sum_player_bar_metrics[team_id][
                "totalDamageDealtToEliteBuildings"
            ],
            "totalDamageDealtToEliteMonsters": sum_player_bar_metrics[team_id][
                "totalDamageDealtToEliteMonsters"
            ],
            "championKills": team_metrics.get("enemyChampionKill", {}).get(
                team_id,
                0,
            ),
            "buildingsKills": team_metrics.get("buildingKill", {}).get(team_id, 0),
            "eliteMonsterKills": team_metrics.get("eliteMonsterKill", {}).get(
                team_id,
                0,
            ),
            "legendaryItems": sum_player_bar_metrics[team_id]["legendaryItems"],
        }
    return bar_metrics
