"""Compute team stats."""

import logging

logger = logging.getLogger(__name__)


def compute_team_stats(postmatch_new_metrics: dict) -> dict:
    """Compute team stats.

    Args:
    ----
        postmatch_new_metrics (dict): postmatch match data.

    Returns:
    -------
        dict: {
            100: {
                "spiderMetrics": {
                    "kd": float,
                    "visionScore": int,
                    "openedLanes": int,
                    "buildingsKilled": int,
                    "dragonsKilled": int,
                    "voidMonstersKilled": int,
                    "averageLevel": float,
                    "goldEarned": int,
                },
            200: {...}
            }
        }

    """
    team_stats = {}
    player_metrics = postmatch_new_metrics["info"]["gamedata"]["players"]
    team_metrics = postmatch_new_metrics["info"]["gamedata"]["teams"]
    enemy_team_id = {
        100: "200",
        200: "100",
    }
    team_sum_score = {
        100: {
            "visionScore": sum(
                value
                for key, value in player_metrics["visionScore"].items()
                if int(key) in range(1, 6)
            ),
            "teamLevel": sum(
                value
                for key, value in player_metrics["champLevel"].items()
                if int(key) in range(1, 6)
            )
            / 5,
            "goldEarned": sum(
                value
                for key, value in player_metrics["goldEarned"].items()
                if int(key) in range(1, 6)
            ),
        },
        200: {
            "visionScore": sum(
                value
                for key, value in player_metrics["visionScore"].items()
                if int(key) in range(6, 11)
            ),
            "teamLevel": sum(
                value
                for key, value in player_metrics["champLevel"].items()
                if int(key) in range(6, 11)
            )
            / 5,
            "goldEarned": sum(
                value
                for key, value in player_metrics["goldEarned"].items()
                if int(key) in range(6, 11)
            ),
        },
    }

    for team_id in [100, 200]:
        team_stats[team_id] = {
            "spiderMetrics": {
                "kd": round(
                    team_metrics["enemyChampionKill"].get(str(team_id), 0)
                    / team_metrics["enemyChampionKill"].get(enemy_team_id[team_id], 1),
                    5,
                ),
                "visionScore": team_sum_score[team_id]["visionScore"],
                "openedLanes": team_metrics.get("openedLanes", {}).get(str(team_id), 0),
                "buildingsKilled": team_metrics.get("buildingKill", {}).get(
                    str(team_id),
                    0,
                ),
                "dragonsKilled": team_metrics.get("dragonKill", {}).get(
                    str(team_id),
                    0,
                ),
                "voidMonstersKilled": team_metrics.get("voidMonsterKill", {}).get(
                    str(team_id),
                    0,
                ),
                "averageLevel": team_sum_score[team_id]["teamLevel"],
                "goldEarned": team_sum_score[team_id]["goldEarned"],
            },
        }
    return team_stats
