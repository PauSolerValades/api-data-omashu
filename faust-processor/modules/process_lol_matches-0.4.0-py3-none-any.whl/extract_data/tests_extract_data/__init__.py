"""Test package for extract_data."""
