"""Extract player, team and match data from postmatch and discretized."""

from .extract_data import compute_stats

__all__ = ["compute_stats"]
