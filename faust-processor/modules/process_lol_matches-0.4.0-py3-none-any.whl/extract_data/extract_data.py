"""Extract stats of team, extract stats of match, extrat stats of player."""

import argparse
import json
import logging
import time
from pathlib import Path

from .compute_stats.match_stats import compute_match_stats
from .compute_stats.player_stats import compute_player_stats
from .compute_stats.team_stats import compute_team_stats

logger = logging.getLogger(__name__)


def main(
    new_metrics_file_path: str,
    output_file_path: str,
) -> None:
    """Extract player, team and match data.

    Args:
    ----
        new_metrics_file_path (str): new_metrics file path
        discretized_file_path (str): discretized file path
        output_file_path (str): output file path

    """
    start_time = time.time()
    new_metrics_relative_path = Path(new_metrics_file_path).resolve()
    output_relative_path = Path(output_file_path).resolve()

    new_metrics_file = new_metrics_relative_path.open(encoding="utf-8")
    output_file = output_relative_path.open("w", encoding="utf-8")
    stats_result = []
    for new_metrics_line in new_metrics_file:
        new_metrics_match = json.loads(new_metrics_line)
        postmatch_new_metrics = new_metrics_match["POSTMATCH"]
        bytime_new_metrics = new_metrics_match["BYTIME"]

        stats_result.append(
            compute_stats(
                postmatch_new_metrics,
                bytime_new_metrics,
            ),
        )

    for stats in stats_result:
        output_file.write(json.dumps(stats) + "\n")

    new_metrics_file.close()
    output_file.close()
    end_time = time.time()
    duration = end_time - start_time
    msg = f"{len(stats_result)} matches in: {duration/60:.2f} minutes"
    logger.info(msg)


def compute_stats(
    postmatch_new_metrics: list[dict],
    bytime_new_metrics: list[dict],
) -> dict:
    """Compute player, team and match stats.

    Args:
    ----
        bytime_new_metrics (list[dict]): bytime and postmatch match data.
        postmatch_new_metrics (list[dict]): postmatch and postmatch match data.

    Returns:
    -------
        dict: player, team and match stats

    """
    try:
        stats = compute_player_stats(postmatch_new_metrics)
        stats["team_stats"] = compute_team_stats(postmatch_new_metrics)
        stats["game_stats"] = compute_match_stats(
            postmatch_new_metrics,
            bytime_new_metrics,
        )
    except ValueError:
        logger.exception("ValueError in match processing")
    except KeyError:
        logger.exception("KeyError in match processing")
    return stats


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Process some text files and integers.",
    )

    parser.add_argument("new_metrics_file", type=str, help="new_metrics txt file path")
    parser.add_argument("output_file", type=str, help="output txt file path")
    parser.add_argument(
        "--deletePreviousOutputFile",
        type=str,
        default=True,
        help="Delete the previous output file, default True",
    )

    args = parser.parse_args()

    script_dir = Path(__file__).resolve()
    new_metrics_path = script_dir / args.new_metrics_file
    output_path = script_dir / args.output_file

    if Path(args.output_file).is_file() and args.deletePreviousOutputFile:
        Path.unlink(args.output_file)

    LEVEL = logging.INFO
    logger.setLevel(LEVEL)

    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")

    Path("logs").mkdir(exist_ok=True)

    file_handler = logging.FileHandler("logs/extract_data.log")
    file_handler.setLevel(LEVEL)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(LEVEL)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    main(args.new_metrics_file, args.output_file)
