"""New metrics module."""

from .new_metrics import new_metrics

__all__ = ["new_metrics"]
