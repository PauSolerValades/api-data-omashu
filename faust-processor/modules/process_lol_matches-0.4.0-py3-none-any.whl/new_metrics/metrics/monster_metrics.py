"""Compute elite monster metrics."""

from collections import defaultdict

from .resources import ELITE_MONSTERS_TYPE, VOID_ELITE_MONSTERS


def all_elite_monster_metrics(elite_monster_kills: dict) -> list[dict, dict]:
    """From ELITE_MONSTER_KILL compute player and team metrics.

    Args:
    ----
        elite_monster_kills (dict): ELITE_MONSTER_KILL, keeps the players data per minute by matchId, order and participantId.

    Returns:
    -------
        "totalEliteMonsterKill", "totalEliteMonsterAssist".
        "voidGrubKill", "dragonKill", "riftHeraldKill", "baronNashorKill".
        "airDragonKill", "chemtechDragonKill", "earthDragonKill", "fireDragonKill", "hextechDragonKill", "waterDragonKill", "elderDragonKill".
        "voidGrubAssist", "dragonAssist", "riftHeraldAssist", "baronNashorAssist".
        "airDragonAssist", "chemtechDragonAssist", "earthDragonAssist", "fireDragonAssist", "hextechDragonAssist", "waterDragonAssist", "elderDragonAssist".

    """
    player_elite_monster_metrics = defaultdict(lambda: defaultdict(int))
    team_elite_monster_metrics = defaultdict(lambda: defaultdict(int))
    for current_event in range(len(elite_monster_kills["monsterType"])):
        metric = "eliteMonsterKill"
        player_elite_monster_metrics[metric][
            elite_monster_kills["killerId"][current_event]
        ] += 1
        team_elite_monster_metrics[metric][
            elite_monster_kills["killerTeamId"][current_event]
        ] += 1
        metric = f"{ELITE_MONSTERS_TYPE[elite_monster_kills['monsterType'][current_event]]}Kill"
        player_elite_monster_metrics[metric][
            elite_monster_kills["killerId"][current_event]
        ] += 1
        team_elite_monster_metrics[metric][
            elite_monster_kills["killerTeamId"][current_event]
        ] += 1
        if (
            "monsterSubType" in elite_monster_kills
            and elite_monster_kills["monsterSubType"][current_event] is not None
        ):
            metric = f"{ELITE_MONSTERS_TYPE[elite_monster_kills['monsterSubType'][current_event]]}Kill"
            player_elite_monster_metrics[metric][
                elite_monster_kills["killerId"][current_event]
            ] += 1
            team_elite_monster_metrics[metric][
                elite_monster_kills["killerTeamId"][current_event]
            ] += 1
        elif elite_monster_kills["monsterType"][current_event] in VOID_ELITE_MONSTERS:
            metric = "voidMonsterKill"
            player_elite_monster_metrics[metric][
                elite_monster_kills["killerId"][current_event]
            ] += 1
            team_elite_monster_metrics[metric][
                elite_monster_kills["killerTeamId"][current_event]
            ] += 1
        if "assistingParticipantIds" in elite_monster_kills:
            for assistant_id in elite_monster_kills["assistingParticipantIds"][
                current_event
            ]:
                metric = "eliteMonsterAssist"
                player_elite_monster_metrics[metric][assistant_id] += 1
                team_elite_monster_metrics[metric][
                    elite_monster_kills["killerTeamId"][current_event]
                ] += 1
                metric = f"{ELITE_MONSTERS_TYPE[elite_monster_kills['monsterType'][current_event]]}Assist"
                player_elite_monster_metrics[metric][assistant_id] += 1
                team_elite_monster_metrics[metric][
                    elite_monster_kills["killerTeamId"][current_event]
                ] += 1
                if (
                    "monsterSubType" in elite_monster_kills
                    and elite_monster_kills["monsterSubType"][current_event] is not None
                ):
                    metric = f"{ELITE_MONSTERS_TYPE[elite_monster_kills['monsterSubType'][current_event]]}Assist"
                    player_elite_monster_metrics[metric][assistant_id] += 1
                    team_elite_monster_metrics[metric][
                        elite_monster_kills["killerTeamId"][current_event]
                    ] += 1
                elif (
                    elite_monster_kills["monsterType"][current_event]
                    in VOID_ELITE_MONSTERS
                ):
                    metric = "voidMonsterAssist"
                    player_elite_monster_metrics[metric][assistant_id] += 1
                    team_elite_monster_metrics[metric][
                        elite_monster_kills["killerTeamId"][current_event]
                    ] += 1

    return dict(player_elite_monster_metrics), dict(team_elite_monster_metrics)


# TODO : elite monster stolen. killerId_teamId != assistingParticipantIds_teamId: killerId +1  # noqa: FIX002, TD002, TD003 (issue not defined yet)
def epic_monsters_stolen(elite_monster_kills: dict) -> dict:  # noqa: ARG001 (arg not used yet)
    """Compute elite monsters stolen by player."""
