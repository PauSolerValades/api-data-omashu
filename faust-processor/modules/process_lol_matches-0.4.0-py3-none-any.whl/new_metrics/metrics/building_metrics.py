"""Building metrics."""

from collections import defaultdict

from .resources import (
    BUILDING_TYPE,
    BUILDING_TYPE_TOTAL,
    LANE_TYPE,
    TEAM_100_ID,
    TURRET_TYPE,
)


def all_building_metrics(building_kills: dict) -> list:
    """From BUILDING_KILL returns 2 dicts, one for building kill and building assist unfolding them by building type.

    Args:
    ----
        building_kills (dict): BUILDING_KILL, keeps the building kills data (bulidingType, laneType and killerId) by matchId and order.

    Returns:
    -------
        Building Metrics:
            "turretKill", "inhibitorKill".
            "topLaneTurretKill", "midLaneTurretKill", "botLaneTurretKill", "nexusTurretKill".
            "topLaneInhibitorKill", "midLaneInhibitorKill", "botLaneInhibitorKill".
            "topLaneTurretAssist", "midLaneTurretAssist", "botLaneTurretAssist", "nexusTurretAssist".
            "topLaneInhibitorAssist", "midLaneInhibitorAssist", "botLaneInhibitorAssist".
        Building Metrics Killed by Minions:
            "topLaneTurretKilledByMinion", "midLaneTurretKilledByMinion", "botLaneTurretKilledByMinion", "nexusTurretKilledByMinion".
            "topLaneInhibitorKilledByMinion", "midLaneInhibitorKilledByMinion", "botLaneInhibitorKilledByMinion".

    """
    player_building_metrics = defaultdict(lambda: defaultdict(int))
    team_building_metrics = defaultdict(lambda: defaultdict(int))
    for current_event in range(len(building_kills["buildingType"])):
        team_killer_id = (
            200 if building_kills["teamId"][current_event] == TEAM_100_ID else 100
        )
        if (
            building_kills["killerId"] == 0
            and building_kills["towerType"][current_event] == "NEXUS_TURRET"
        ):
            metric = f"{TURRET_TYPE[building_kills['towerType'][current_event]]}KilledByMinion"
            team_building_metrics[metric][team_killer_id] += 1
        elif (
            building_kills["killerId"] == 0
            and building_kills["towerType"][current_event] != "NEXUS_TURRET"
        ):
            metric = f"{LANE_TYPE[building_kills['laneType'][current_event]]}{BUILDING_TYPE[building_kills['buildingType'][current_event]]}KilledByMinion"
            team_building_metrics[metric][team_killer_id] += 1
        elif building_kills["towerType"][current_event] == "BASE_TURRET":
            metric = "openedLanes"
            team_building_metrics[metric][team_killer_id] += 1
        else:
            metric = "buildingKill"
            player_building_metrics[metric][
                building_kills["killerId"][current_event]
            ] += 1
            team_building_metrics[metric][team_killer_id] += 1
            if building_kills["towerType"][current_event] == "NEXUS_TURRET":
                metric = (
                    f"{TURRET_TYPE[building_kills['towerType'][current_event]]}Kill"
                )
                player_building_metrics[metric][
                    building_kills["killerId"][current_event]
                ] += 1
                team_building_metrics[metric][team_killer_id] += 1
            else:
                metric = f"{BUILDING_TYPE_TOTAL[building_kills['buildingType'][current_event]]}Kill"
                player_building_metrics[metric][
                    building_kills["killerId"][current_event]
                ] += 1
                team_building_metrics[metric][team_killer_id] += 1

                metric = f"{LANE_TYPE[building_kills['laneType'][current_event]]}{BUILDING_TYPE[building_kills['buildingType'][current_event]]}Kill"
                player_building_metrics[metric][
                    building_kills["killerId"][current_event]
                ] += 1
                team_building_metrics[metric][team_killer_id] += 1

        for assistant_id in building_kills["assistingParticipantIds"][current_event]:
            metric = "buildingAssist"
            player_building_metrics[metric][assistant_id] += 1
            team_building_metrics[metric][team_killer_id] += 1
            if building_kills["towerType"][current_event] == "NEXUS_TURRET":
                metric = (
                    f"{TURRET_TYPE[building_kills['towerType'][current_event]]}Assist"
                )
                player_building_metrics[metric][assistant_id] += 1
                team_building_metrics[metric][team_killer_id] += 1
            else:
                metric = f"{BUILDING_TYPE_TOTAL[building_kills['buildingType'][current_event]]}Assist"
                player_building_metrics[metric][assistant_id] += 1
                team_building_metrics[metric][team_killer_id] += 1

                metric = f"{LANE_TYPE[building_kills['laneType'][current_event]]}{BUILDING_TYPE[building_kills['buildingType'][current_event]]}Assist"
                player_building_metrics[metric][assistant_id] += 1
                team_building_metrics[metric][team_killer_id] += 1

    return player_building_metrics, team_building_metrics


def all_turret_plate_metrics(turret_plate_events: dict) -> dict:
    """From TURRET_PLATE_DESTROYED returns a dict for turret plate kill unfolding them by lane type.

    Args:
    ----
        turret_plate_events (dict): TURRET_PLATE_DESTROYED, keeps the turret plate kills data (laneType and killerId) by matchId and order.

    Returns:
    -------
        TODO: revisar noms i doanr feedback a Manu.

    """
    player_plate_metrics = defaultdict(lambda: defaultdict(int))
    team_plate_metrics = defaultdict(lambda: defaultdict(int))
    for current_event in range(len(turret_plate_events["laneType"])):
        team_kill_id = (
            200 if turret_plate_events["teamId"][current_event] == TEAM_100_ID else 100
        )
        if turret_plate_events["killerId"][current_event] == 0:
            metric = f"{LANE_TYPE[turret_plate_events['laneType'][current_event]]}{turret_plate_events['teamId'][current_event]}TurretPlateKilledByMinions"
            team_plate_metrics[metric][team_kill_id] += 1
        else:
            metric = "turretPlateKill"
            player_plate_metrics[metric][
                turret_plate_events["killerId"][current_event]
            ] += 1
            team_plate_metrics[metric][team_kill_id] += 1
            metric = f"{LANE_TYPE[turret_plate_events['laneType'][current_event]]}TurretPlateKill"
            player_plate_metrics[metric][
                turret_plate_events["killerId"][current_event]
            ] += 1
            team_plate_metrics[metric][team_kill_id] += 1
    return dict(player_plate_metrics), dict(team_plate_metrics)
