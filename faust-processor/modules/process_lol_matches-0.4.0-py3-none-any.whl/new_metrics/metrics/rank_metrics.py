"""Compute rank metrics (average, mode, median, highest and lowest) for a group of players."""

from collections import Counter, defaultdict

import numpy as np

from .resources import DIVISIONS, HIGH_TIER, LOW_TIER

tiers = LOW_TIER + HIGH_TIER

# Create enumerations for sorting
enum_tiers = {tier: i for i, tier in enumerate(tiers, start=1)}
enum_tier_division = {
    f"{tier}#{division}": i for i, tier in enumerate(LOW_TIER) for division in DIVISIONS
}
enum_tier_division.update(
    {f"{tier}#I": len(enum_tier_division) + i + 1 for i, tier in enumerate(HIGH_TIER)},
)


def process_rank(rank: dict) -> dict:
    """Process players rank to compute teams and match rank metrics.

    Args:
    ----
        rank (dict): Players rank data.

    Returns:
    -------
        dict: match, team100 and team200 rank data.

    """
    team_rank = {}
    match_rank = {}

    team_rank[100] = compute_rank_metrics(dict(list(rank.items())[:5]))
    team_rank[200] = compute_rank_metrics(dict(list(rank.items())[5:]))
    match_rank = compute_rank_metrics(rank)
    return match_rank, team_rank


def compute_rank_metrics(rank_data: dict) -> dict:
    """Compute teams and match mode_rank, average_rank, highest_rank, lowest_rank and median_rank.

    Args:
    ----
        rank_data (dict): players rank data
        {
            puuid_1: {tier: , division: },
            ...
            puuid_10: {tier: , division: },
        }

    Returns:
    -------
        dict: {
            "mode": {tier: , division: },
            "average": {tier: , division: },
            "highest": {tier: , division: },
            "lowest": {tier: , division: },
            "median": {tier: , division: }
        }

    """
    match_rank = defaultdict(dict)

    rank_functions = {
        "mode": mode_rank,
        "average": average_rank,
        "highest": highest_rank,
        "lowest": lowest_rank,
        "median": median_rank,
    }
    for key, func in rank_functions.items():
        tier, tier_div = func(rank_data)
        match_rank[key] = {"tier": tier, "tierDiv": tier_div}

    return match_rank


def tier_sort(tier: str) -> int:
    """Sort tier from lower to higher."""
    return enum_tiers.get(tier, 0)


def tier_division_sort(tier: str, division: str) -> int:
    """Sort tier and division from lower to higher."""
    return enum_tier_division.get(f"{tier}#{division}", 0)


def mode_rank(rank: dict[str, dict[str, str]]) -> list[dict, dict]:
    """Compute mode rank for a group of players."""
    count_tiers = Counter()
    count_tiers_divisions = Counter()

    for value in rank.values():
        tier = value["tier"]
        division = value["division"]
        count_tiers[tier] += 1
        count_tiers_divisions[f"{tier}#{division}"] += 1

    max_tier = max(count_tiers.items(), key=lambda x: (x[1], tier_sort(x[0])))[0]
    max_tier_division = max(
        count_tiers_divisions.items(),
        key=lambda x: (x[1], tier_division_sort(*x[0].split("#"))),
    )[0]

    return max_tier, max_tier_division


def average_rank(rank: dict[str, dict[str, str]]) -> list[dict, dict]:
    """Compute average rank for a group of players."""
    tier_average = np.mean([tier_sort(value["tier"]) for value in rank.values()])
    tier_div_average = np.mean(
        [
            tier_division_sort(value["tier"], value["division"])
            for value in rank.values()
        ],
    )
    return tier_average, tier_div_average


def highest_rank(rank: dict[str, dict[str, str]]) -> list[dict, dict]:
    """Compute highest rank for a group of players."""
    tiers = [(value["tier"], tier_sort(value["tier"])) for value in rank.values()]
    tiers_divs = [
        (
            f'{value["tier"]}#{value["division"]}',
            tier_division_sort(value["tier"], value["division"]),
        )
        for value in rank.values()
    ]

    max_tier = max(tiers, key=lambda x: x[1])[0]
    max_tier_division = max(tiers_divs, key=lambda x: x[1])[0]

    return max_tier, max_tier_division


def lowest_rank(rank: dict[str, dict[str, str]]) -> list[dict, dict]:
    """Compute lowest rank for a group of players."""
    tiers = [(value["tier"], tier_sort(value["tier"])) for value in rank.values()]
    tiers_divs = [
        (
            f'{value["tier"]}#{value["division"]}',
            tier_division_sort(value["tier"], value["division"]),
        )
        for value in rank.values()
    ]

    min_tier = min(tiers, key=lambda x: x[1])[0]
    min_tier_division = min(tiers_divs, key=lambda x: x[1])[0]

    return min_tier, min_tier_division


def median_rank(rank: dict[str, dict[str, str]]) -> list[dict, dict]:
    """Compute median rank for a group of players."""
    tiers = sorted([value["tier"] for value in rank.values()], key=tier_sort)
    tiers_divs = sorted(
        [f'{value["tier"]}#{value["division"]}' for value in rank.values()],
        key=lambda x: tier_division_sort(*x.split("#")),
    )

    median_tier = tiers[len(tiers) // 2]
    median_tier_division = tiers_divs[len(tiers_divs) // 2]

    return median_tier, median_tier_division
