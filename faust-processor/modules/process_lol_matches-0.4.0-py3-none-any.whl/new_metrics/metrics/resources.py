"""Resources to compute new metrics."""

TEAM_100_ID = 100
PLAYERS_ID_TEAM_100 = [1, 2, 3, 4, 5]
BUILDING_TYPE = {
    "TOWER_BUILDING": "Turret",
    "INHIBITOR_BUILDING": "Inhibitor",
}

BUILDING_TYPE_TOTAL = {
    "TOWER_BUILDING": "turret",
    "INHIBITOR_BUILDING": "inhibitor",
}

LANE_TYPE = {
    "TOP_LANE": "topLane",
    "MID_LANE": "midLane",
    "BOT_LANE": "botLane",
}

TURRET_TYPE = {
    "OUTER_TURRET": "OuterTurret",
    "INNER_TURRET": "InnerTurret",
    "BASE_TURRET": "InhibitorTurret",
    "NEXUS_TURRET": "nexusTurret",
}

WORLD_ATLAS_ID = 3865
RUNIC_COPASS_ID = 3866
EYE_OF_THE_HERALD = 3513

POSITION = {
    "TOP": "Top",
    "JUNGLE": "Jungle",
    "MIDDLE": "Middle",
    "BOTTOM": "Bottom",
    "UTILITY": "Utility",
}

THRESHOLD = 0.35


# Minions spawned until minute 90
def total_minions_spawned() -> list[int]:
    """Compute total minions spawned depending on the match len."""
    total_minions_spawned = [0]
    increments = [6] + [13, 12, 13] * 4 + [13] * 12 + [14] * 34 + [15] * 31
    for inc in increments:
        total_minions_spawned.append(total_minions_spawned[-1] + inc)
    return total_minions_spawned


MINIONS_SPAWNED_PER_MINUTE = {
    "wavesSpawned": [0, 1] + [2] * 89,
    "totalWavesSpawned": [0, 1, *list(range(3, 180, 2))],
    "minionsSpawnedPerMinute": [0, 6]
    + [13, 12, 13] * 4
    + [13] * 12
    + [14] * 35
    + [15] * 30,
    "totalMinionsSpawned": total_minions_spawned(),
}

VOID_ELITE_MONSTERS = [
    "HORDE",
    "RIFTHERALD",
    "BARON_NASHOR",
]

ELITE_MONSTERS_TYPE = {
    "HORDE": "voidGrub",
    "AIR_DRAGON": "airDragon",
    "CHEMTECH_DRAGON": "chemtechDragon",
    "EARTH_DRAGON": "earthDragon",
    "FIRE_DRAGON": "fireDragon",
    "HEXTECH_DRAGON": "hextechDragon",
    "WATER_DRAGON": "waterDragon",
    "ELDER_DRAGON": "elderDragon",
    "DRAGON": "dragon",
    "RIFTHERALD": "riftHerald",
    "BARON_NASHOR": "baronNashor",
}

LOW_TIER = ["IRON", "BRONZE", "SILVER", "GOLD", "PLATINUM", "EMERALD", "DIAMOND"]
HIGH_TIER = ["MASTER", "GRANDMASTER", "CHALLENGER"]
DIVISIONS = ["I", "II", "III", "IV"]
