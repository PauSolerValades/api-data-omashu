"""Compute minion metrics."""

from collections import defaultdict

from .resources import MINIONS_SPAWNED_PER_MINUTE

MAX_MATCH_LENGHT = 90


def all_minions_metrics(
    minions_killed: list,
    utility_quest_completed: dict,
) -> dict:
    """From minionsKilled list and the minions_spawned_per_minute DataFrame returns minionMetrics dict per participantId.

    Args:
    ----
        minions_killed (list): participantFrames, minions killed.
        utility_quest_completed (dict): utility's quest completed minute.

    Returns:
    -------
        dict: "minionEfficiency", "waveEfficiency", "waveDoneEfficiency", "waveNotDoneEfficiency".

    """
    minion_metrics = defaultdict(dict)
    total_minions_spawned = MINIONS_SPAWNED_PER_MINUTE["totalMinionsSpawned"]

    for participant_id in range(1, 11):
        minion_metrics["minionsKilled"][participant_id] = minions_killed[
            participant_id
        ][-1]
        game_length = len(minions_killed[participant_id]) - 1
        minion_metrics["minionEfficency"][participant_id] = (
            minions_killed[participant_id][game_length]
            / total_minions_spawned[game_length - 1]
        )
    if utility_quest_completed:
        for utility_id in utility_quest_completed:
            if utility_quest_completed[utility_id]["questStart"]["minute"]:
                quest_start = utility_quest_completed[utility_id]["questStart"][
                    "minute"
                ]

                if utility_quest_completed[utility_id]["questCompleted"]["minute"]:
                    quest_completed = utility_quest_completed[utility_id][
                        "questCompleted"
                    ]["minute"]
                else:
                    quest_completed = len(minions_killed[utility_id]) - 1
                utility_minions_killed = (
                    minions_killed[utility_id][quest_completed]
                    - minions_killed[utility_id][quest_start]
                )
                minions_spawned = (
                    total_minions_spawned[quest_completed]
                    - total_minions_spawned[quest_start]
                )
                minion_metrics["minionsConceeded"][utility_id] = minions_conceeded(
                    utility_minions_killed,
                    minions_spawned,
                )
    return dict(minion_metrics)


def minions_conceeded(
    minions_killed: int,
    total_minions_spawned: int,
    const: float = 2.0,
) -> float:
    """Compute minions conceeded.

    Args:
    ----
        minions_killed (int): minions killed by utility
        total_minions_spawned (int): total minions spawned per lane
        const (float, optional): _description_. Defaults to 2.0.

    Returns:
    -------
        float: Minions

    """
    return (
        1 - ((minions_killed * const) / total_minions_spawned)
        if total_minions_spawned != 0
        else 1
    )
