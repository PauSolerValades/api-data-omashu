"""Process item events."""

import logging
from collections import defaultdict

from .resources import EYE_OF_THE_HERALD, RUNIC_COPASS_ID, WORLD_ATLAS_ID

logger = logging.getLogger("newmetrics")


def treat_item_events(item_events: dict) -> dict:
    """Process item events. Only compatible with item purchased, item destroyed and item sold events.

    Args:
    ----
        item_events (dict): bytime item events.

    Returns:
    -------
        dict: items purchased, destroyed or sold per player with this structure:
            {
                participant: {
                    item_id: [
                        {timestamp: [int]},
                        {eventOrd: [int]}
                    ]
                }
            }.

    """
    item_interaction = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    for current_event in range(len(item_events["itemId"])):
        item_id = item_events["itemId"][current_event]
        participant_id = item_events["participantId"][current_event]
        timestamp = item_events["timestamp"][current_event]
        event_ord = item_events["eventOrd"][current_event]
        item_interaction[participant_id][item_id]["timestamp"].append(timestamp)
        item_interaction[participant_id][item_id]["eventOrd"].append(event_ord)

    return dict(item_interaction)


def treat_item_undo_events(item_undo_events: dict) -> dict:
    """Process item undo events.

    Args:
    ----
        item_undo_events (dict): bytime item undo events.

    Returns:
    -------
        dict: items undo per player with this structure:
            {
                participant: {
                    item_id_before_undo: [
                        {item_id_after_undo: timestamp}
                    ]
                }
            }.

    """
    item_undo = defaultdict(lambda: defaultdict(list))
    for current_event in range(len(item_undo_events["beforeId"])):
        before_id = item_undo_events["beforeId"][current_event]
        participant_id = item_undo_events["participantId"][current_event]
        timestamp = item_undo_events["timestamp"][current_event]
        item_undo[participant_id][before_id].append(timestamp)
    return dict(item_undo)


def compute_items_used(items_purchased: dict, items_undo: dict) -> dict:
    """Build a history of items purchased by each participant and track how many times each item was bought.

    Args:
    ----
        items_purchased (dict): items purchased per participant.
        items_undo (dict): item interaction undoid per participant.

    Returns:
    -------
        dict: {
            participant_id_1:{
                item_id_1: times_intentionaly_purchased,
                ...,
                item_id_1: times_intentionaly_purchased,
            },
            ...,
            participant_id_10:{...},
        }

    """
    items_purchased_history = defaultdict(lambda: defaultdict(int))
    for participant_id, player_items_purcahsed in items_purchased.items():
        for item_id, time_data in player_items_purcahsed.items():
            items_purchased_history[participant_id][item_id] = len(
                time_data["timestamp"],
            )
    for participant_id, player_items_undo in items_undo.items():
        items_purchased_by_participant = items_purchased_history[participant_id]
        for old_item_id in player_items_undo:
            items_purchased_by_participant[old_item_id] -= 1
        # After handeling item undo events, delete item id 0 (absence of item)
        if 0 in items_purchased_history[participant_id]:
            items_purchased_by_participant.pop(0)
    return {"itemsUsed": items_purchased_history}


def utility_quest_completed(
    items_purchased: dict,
    items_destroyed: dict,
) -> dict:
    """Compute support quest starts and completed minutes and timestsamps.

    Support quest start when the utility position player buys the item wold atlas, and it's completed when runic compass is destroyed.

    Args:
    ----
        items_purchased (dict): item purchased processed events
        items_destroyed (dict): item destroyed processed events

    Returns:
    -------
        dict: start and completed utility quest timestamp for participant id.

    """
    utility_quest = defaultdict(
        lambda: {
            "questStart": {"minute": None, "timestamp": None, "eventOrd": None},
            "questCompleted": {"minute": None, "timestamp": None, "eventOrd": None},
        },
    )
    for participant_id in range(1, 11):
        if items_purchased and participant_id in items_purchased:
            for item_purchased_id in items_purchased[participant_id]:
                quest_start = utility_quest[participant_id]["questStart"]
                if item_purchased_id != WORLD_ATLAS_ID:
                    continue
                world_atlas_data = items_purchased[participant_id][WORLD_ATLAS_ID]
                quest_start["minute"] = 1 + (world_atlas_data["timestamp"][0]) // 60000
                quest_start["timestamp"] = world_atlas_data["timestamp"][0]
                quest_start["eventOrd"] = world_atlas_data["eventOrd"][0]
        if items_destroyed and participant_id in items_destroyed:
            for item_destroyed_id in items_destroyed[participant_id]:
                quest_end = utility_quest[participant_id]["questCompleted"]
                if item_destroyed_id != RUNIC_COPASS_ID:
                    continue
                runic_compass_data = items_destroyed[participant_id][RUNIC_COPASS_ID]
                quest_end["minute"] = 1 + (runic_compass_data["timestamp"][-1]) // 60000
                quest_end["timestamp"] = runic_compass_data["timestamp"][-1]
                quest_end["eventOrd"] = runic_compass_data["eventOrd"][-1]
    return dict(utility_quest)


def create_bytime_event_from_items(
    destroy_item_events: dict,
    utility_quest: dict,
    linked_events: dict,
) -> None:
    """Create bytime events from item destroyed events.

    Args:
    ----
        destroy_item_events (dict): item destroy bytime event.
        utility_quest (dict): support item quest data per participant.
        linked_events (dict): linked bytime events to update.

    """
    # SUPPORT_QUEST
    linked_events["SUPPORT_QUEST"] = {
        "participantId": [],
        "timestampQuestStart": [],
        "timestampQuestCompleted": [],
        "startEventAssociated": [],
        "endEventAssociated": [],
        "questCompleted": [],
    }
    for participant_id, quest_data in utility_quest.items():
        linked_events["SUPPORT_QUEST"]["participantId"].append(participant_id)
        linked_events["SUPPORT_QUEST"]["timestampQuestStart"].append(
            quest_data["questStart"]["timestamp"],
        )
        linked_events["SUPPORT_QUEST"]["timestampQuestCompleted"].append(
            quest_data["questCompleted"]["timestamp"],
        )
        linked_events["SUPPORT_QUEST"]["startEventAssociated"].append(
            quest_data["questStart"]["eventOrd"],
        )
        linked_events["SUPPORT_QUEST"]["endEventAssociated"].append(
            quest_data["questCompleted"]["eventOrd"],
        )
        linked_events["SUPPORT_QUEST"]["questCompleted"].append(
            True if quest_data["questCompleted"]["eventOrd"] else None,
        )

    # INVOKE_RIFT_HERALD
    linked_events["INVOKE_RIFT_HERALD"] = {
        "timestamp": [],
        "eventOrd": [],
        "participantId": [],
    }
    for curret_item_event, item_id in enumerate(destroy_item_events["itemId"]):
        if item_id == EYE_OF_THE_HERALD:
            linked_events["INVOKE_RIFT_HERALD"]["timestamp"].append(
                destroy_item_events["timestamp"][curret_item_event],
            )
            linked_events["INVOKE_RIFT_HERALD"]["eventOrd"].append(
                destroy_item_events["eventOrd"][curret_item_event],
            )
            linked_events["INVOKE_RIFT_HERALD"]["participantId"].append(
                destroy_item_events["participantId"][curret_item_event],
            )
