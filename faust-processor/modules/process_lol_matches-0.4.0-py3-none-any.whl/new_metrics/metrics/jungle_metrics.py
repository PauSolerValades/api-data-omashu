"""Compute jungle monsters efficency."""

from collections import defaultdict

import numpy as np


def all_jungle_minions_metrics(
    jungle_monsters_killed: list,
) -> dict:
    """Compute jungleMonstersEfficiency from participantFrames jungle_monsters_killed and total_jungle_monsters_killed.

    Args:
    ----
        jungle_monsters_killed (list): participantFrames, Jungle Minions Killed.

    Returns:
    -------
        dict: jungle_monsters_efficiency.

    """
    jungle_efficiency = defaultdict(dict)
    jungle_minions_len = len(jungle_monsters_killed[1])
    total_jungle_monster_killed = [0 for _ in range(jungle_minions_len)]

    for participant_id in jungle_monsters_killed:
        for time_index in range(jungle_minions_len):
            total_jungle_monster_killed[time_index] += jungle_monsters_killed[
                participant_id
            ][time_index]

    jungle_monsters_efficiency = [0 for _ in range(jungle_minions_len)]
    for participant_id in jungle_monsters_killed:
        for time_index in range(jungle_minions_len):
            jungle_monsters_efficiency[time_index] = (
                np.divide(
                    jungle_monsters_killed[participant_id][time_index],
                    total_jungle_monster_killed[time_index],
                )
                if jungle_monsters_killed[participant_id][time_index] != 0
                else 0
            )
        jungle_efficiency["jungleMonstersEfficency"][participant_id] = int(
            np.mean(
                jungle_monsters_efficiency,
            ),
        )

    return dict(jungle_efficiency)
