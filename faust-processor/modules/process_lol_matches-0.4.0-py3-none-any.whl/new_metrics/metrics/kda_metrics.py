"""Compute kda metrics."""

from collections import defaultdict

from .resources import PLAYERS_ID_TEAM_100, POSITION


def all_position_kill_metrics(
    champion_kills: dict,
    team_position_id: dict,
) -> list[dict, dict]:
    """From CHAMPION_KILL returns player and team metrics dicts.

    Args:
    ----
        champion_kills (dict): CHAMPION_KILL, keeps the champion kills data (victimId, killerId and assistingParticipantIds is what this function uses) by matchId and order.
        team_position_id (dict): relation between participant id and team position.

    Returns:
    -------
        "enemyChampionKill": count of enemy champions killed.
        "enemyTopKill": count of enemy Top Position Killed.
        "enemyJungleKill": count of enemy Jungle Position Killed.
        "enemyMiddleKill": count of enemy Middle Position Killed.
        "enemyBottomKill": count of enemy Bottom Position Killed.
        "enemyUtilityKill": count of enemy Utility Position Killed
        "alliedTopKillAssist": count of allied Top Position Kills Assisted.
        "alliedJungleKillAssist": count of allied Jungle Position Kills Assisted.
        "alliedMiddleKillAssist": count of allied Middle Position Kills Assisted.
        "alliedBottomKillAssist": count of allied Bottom Position Kills Assisted.
        "alliedUtilityKillAssist": count of allied Utility Position Kills Assisted.
        "enemyChampionDeathAssisted": count of enemy champion deaths
        "enemyTopDeathAssisted": count of enemy Top Position Death Assisted.
        "enemyJungleDeathAssisted": count of enemy Jungle Position Death Assisted.
        "enemyMiddleDeathAssisted": count of enemy Middle Position Death Assisted.
        "enemyBottomDeathAssisted": count of enemy Bottom Position Death Assisted.
        "enemyUtilityDeathAssisted": count of enemy Utility Position Death Assisted.

    """
    player_kda_metrics = defaultdict(lambda: defaultdict(int))
    team_kda_metrics = defaultdict(lambda: defaultdict(int))
    for current_event in range(len(champion_kills["victimId"])):
        killer_team_id = (
            100
            if champion_kills["killerId"][current_event] in PLAYERS_ID_TEAM_100
            else 200
        )
        metric = "enemyChampionKill"
        player_kda_metrics[metric][champion_kills["killerId"][current_event]] += 1
        team_kda_metrics[metric][killer_team_id] += 1
        metric = f"enemy{POSITION[team_position_id[champion_kills['victimId'][current_event]]]}Kill"
        player_kda_metrics[metric][champion_kills["killerId"][current_event]] += 1
        team_kda_metrics[metric][killer_team_id] += 1

        if champion_kills["assistingParticipantIds"]:
            for assistant_id in champion_kills["assistingParticipantIds"][
                current_event
            ]:
                metric = "enemyChampionDeathAssisted"
                player_kda_metrics[metric][assistant_id] += 1
                team_kda_metrics[metric][killer_team_id] += 1
                metric = f"allied{POSITION[team_position_id[champion_kills['killerId'][current_event]]]}KillAssist"
                player_kda_metrics[metric][assistant_id] += 1
                team_kda_metrics[metric][killer_team_id] += 1
                metric = f"enemy{POSITION[team_position_id[champion_kills['victimId'][current_event]]]}DeathAssisted"
                player_kda_metrics[metric][assistant_id] += 1

    return player_kda_metrics, team_kda_metrics


def handle_special_kill(
    kill_events: dict,
    linked_events: dict,
) -> None:
    """Classify champion special kill by type (KILL_MULTI, KILL_ACE or KILL_FIRST_BLOOD).

    Args:
    ----
        kill_events (dict): all champion kill bytime events.
        linked_events (dict): all linked bytime events to be updated.

    """
    special_kill_events = linked_events["CHAMPION_SPECIAL_KILL"]
    current_multykill_event = 0
    special_events = enumerate(special_kill_events["eventOrd"])
    for current_event, special_event_order in special_events:
        special_kill_type = special_kill_events["killType"][current_event]
        if "KILL_MULTI" in special_kill_type:
            multikill_events = defaultdict(list)
            kill_streak_length = special_kill_events["multiKillLength"][
                current_multykill_event
            ]
            i_kill = kill_events["eventOrd"].index(special_event_order)
            iterate_upon = range(i_kill - kill_streak_length + 1, i_kill + 1)
            for i_champion_kill in iterate_upon:
                multikill_events["killerId"].append(
                    special_kill_events["killerId"][current_event],
                )
                multikill_events["victimId"].append(
                    kill_events["victimId"][i_champion_kill],
                )
                multikill_events["timestamp"].append(
                    kill_events["timestamp"][i_champion_kill],
                )
                multikill_events["eventOrd"].append(
                    kill_events["eventOrd"][i_champion_kill],
                )
            linked_events["MULTI_KILL"] = dict(multikill_events)

        elif "KILL_ACE" in special_kill_type:
            ace_events = defaultdict(list)
            i_kill = kill_events["eventOrd"].index(special_event_order)
            ace_events["killerId"].append(kill_events["killerId"][i_kill])
            ace_events["victimId"].append(kill_events["victimId"][i_kill])
            ace_events["timestamp"].append(kill_events["timestamp"][i_kill])
            ace_events["eventOrd"].append(kill_events["eventOrd"][i_kill])
            linked_events["KILL_ACE"] = dict(ace_events)

        elif "KILL_FIRST_BLOOD" in special_kill_type:
            first_blod_event = defaultdict(list)
            i_kill = kill_events["eventOrd"].index(special_event_order)
            first_blod_event["killerId"].append(kill_events["killerId"][i_kill])
            first_blod_event["victimId"].append(kill_events["victimId"][i_kill])
            first_blod_event["timestamp"].append(kill_events["timestamp"][i_kill])
            first_blod_event["eventOrd"].append(kill_events["eventOrd"][i_kill])
            linked_events["FIRST_BLOOD"] = dict(first_blod_event)
        elif special_kill_type:
            msg = f"Not handeled CHAMPION_SPECIAL_KILL killType: {special_kill_type}"
            raise KeyError(msg)
