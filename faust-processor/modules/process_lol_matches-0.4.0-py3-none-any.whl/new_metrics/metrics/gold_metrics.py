"""Compute gold usage."""

from collections import defaultdict

import numpy as np


def gold_usage_metrics(
    current_gold: list,
    total_gold: list,
) -> dict:
    """Compute goldUsage from participantFrames current_gold and total_gold.

    Args:
    ----
        current_gold (list): participantFrames, Current Gold.
        total_gold (list): participantFrames, Total Gold.

    Returns:
    -------
        dict: Gold Usage.

    """
    gold_usage = defaultdict(dict)
    # To be revised
    for participant_id in list(range(1, 11)):
        gold_spent = np.subtract(
            total_gold[participant_id],
            current_gold[participant_id],
        )
        efficiency = np.divide(gold_spent, total_gold[participant_id])
        absolute_gold_difference = np.abs(
            np.divide(total_gold[participant_id], 100) - np.divide(gold_spent, 100),
        )
        management = np.divide(
            1,
            np.add(np.multiply(2e-2, np.power(absolute_gold_difference, 2)), 1),
        )
        player_gold_usage = np.multiply(efficiency, management)

        gold_usage["goldUsage"][participant_id] = player_gold_usage.mean()

    return dict(gold_usage)
