"""Test gold funcitons."""

import sys
import unittest
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from metrics.gold_metrics import gold_usage_metrics


class EventMetricsTests(unittest.TestCase):
    """Test gold fuctions."""

    def test_gold_usage_metrics(self) -> None:
        """Test building function."""
        current_gold = {
            1: [500, 0, 84],
            2: [500, 5, 116],
            3: [500, 0, 91],
            4: [500, 0, 84],
            5: [500, 0, 24],
            6: [500, 0, 77],
            7: [500, 0, 111],
            8: [500, 5, 110],
            9: [500, 0, 98],
            10: [500, 0, 32],
        }
        total_gold = {
            1: [500, 500, 584],
            2: [500, 505, 616],
            3: [500, 500, 591],
            4: [500, 500, 584],
            5: [500, 500, 524],
            6: [500, 500, 577],
            7: [500, 500, 611],
            8: [500, 505, 610],
            9: [500, 500, 598],
            10: [500, 500, 532],
        }
        gold_usage = gold_usage_metrics(current_gold, total_gold)
        expected_gold_usage = {
            "goldUsage": {
                1: 0.6147501076678066,
                2: 0.5934887090155627,
                3: 0.6107467092229438,
                4: 0.6147501076678066,
                5: 0.6510335005015698,
                6: 0.6187986609835453,
                7: 0.5995500885722844,
                8: 0.596784754492241,
                9: 0.606787623768584,
                10: 0.6459762486627887,
            },
        }
        self.assertEqual(gold_usage, expected_gold_usage)
