"""."""

import argparse
import json
import logging
from collections import defaultdict
from pathlib import Path

from .metrics.building_metrics import (
    all_building_metrics,
    all_turret_plate_metrics,
)
from .metrics.gold_metrics import gold_usage_metrics
from .metrics.item_metrics import (
    compute_items_used,
    create_bytime_event_from_items,
    treat_item_events,
    treat_item_undo_events,
    utility_quest_completed,
)
from .metrics.jungle_metrics import all_jungle_minions_metrics
from .metrics.kda_metrics import all_position_kill_metrics, handle_special_kill
from .metrics.minions_metrics import all_minions_metrics
from .metrics.monster_metrics import all_elite_monster_metrics
from .metrics.rank_metrics import process_rank

logger = logging.getLogger(__name__)


def main(input_file: str, output_file: str) -> None:
    """From postmatch and bytime data calcules the new metrics and saves them with non-repeated postmatch data.

    Args:
    ----
        input_file (str): txt file with one json match data per line.
        output_file (str): txt file with one new metrics json match data per line.

    """
    input_path = Path(input_file).resolve()
    output_path = Path(output_file).resolve()

    infile = input_path.open(encoding="utf-16")
    outfile = output_path.open("a", encoding="utf-16")

    total_matches = 0

    postmatch = None
    bytime = None

    for line in infile:
        try:
            data = json.loads(line)
        except json.JSONDecodeError as e:
            msg = f"Error al parsear JSON: {e}"
            logger.exception(msg)
            continue

        data_type = data.get("dataType")
        if data_type == "POSTMATCH":
            postmatch = data
        elif data_type == "BYTIME":
            bytime = data
        else:
            msg = f"Incorrect data type: {data_type}"
            logger.warning(msg)
            continue
        if postmatch and bytime and postmatch["matchId"] == bytime["matchId"]:
            # Postmatch and Bytime are from the same match.
            try:
                new_metrics(bytime["data"], postmatch["data"])
                new_metrics_match = {"BYTIME": bytime, "POSTMATCH": postmatch}
            except json.JSONDecodeError as e:
                msg = f"JSONDecodeError: {e} - Possibly malformed JSON in this line"
                logger.exception(msg)
            except KeyError as e:
                msg = f"KeyError: {e} - Key not found in JSON object"
                logger.exception(msg)
            except ValueError as e:
                msg = (
                    f"ValueError: {e} - Length of match over 90 minutes. Skipping match"
                )
                logger.exception(msg)
                continue
            outfile.write(json.dumps(new_metrics_match) + "\n")
            logger.debug(postmatch["matchId"])
            total_matches += 1
            msg = f"{total_matches} processed"
            logger.info(msg)

    infile.close()
    outfile.close()


def new_metrics(bytime: dict, postmatch: dict) -> None:
    """Compute all metrics from bytime data and updates postmatch dict.

    Computes three types of metrics:
    - objective: calculates metrics from the events
    - events: calculates metrics obtained from items
    - participant:

    Args:
    ----
        bytime (dict): bytime data.
        postmatch (dict): postmatch data.

    """
    json_events = bytime["info"]["events"]
    linked_events = bytime["info"]["linkedEvents"]
    events_in_match = bytime["info"]["events"].keys()
    json_participant_frames = bytime["info"]["participantFrames"]

    players_metrics, team_metrics = compute_objective_metrics(
        json_events,
        linked_events,
        events_in_match,
        postmatch["metadata"]["teamPositionId"],
    )

    items_used, utility_quest = process_item_events(
        json_events,
        linked_events,
        events_in_match,
    )

    participant_metrics = compute_participant_frames_metrics(
        json_participant_frames,
        utility_quest,
    )

    players_metrics.append(participant_metrics)
    players_metrics.append(items_used)

    player_match_metrics = merge_dicts(*players_metrics)
    postmatch["info"]["gamedata"]["players"] = merge_dicts(
        postmatch["info"]["gamedata"]["players"],
        player_match_metrics,
    )

    team_match_metrics = merge_dicts(*team_metrics)
    postmatch["info"]["gamedata"]["teams"] = merge_dicts(
        postmatch["info"]["gamedata"]["teams"],
        team_match_metrics,
    )

    if "rank" in postmatch:
        rank = postmatch.pop("rank")
        player_rank = defaultdict(str)
        for pid, puuid in enumerate(rank):
            logger.debug(pid)
            player_rank[str(pid + 1)] = (
                f"{rank[puuid]['tier']}#{rank[puuid]['division']}"
            )
        match_rank, team_rank = process_rank(rank)
        postmatch["info"]["gamedata"]["players"]["rank"] = player_rank
        postmatch["info"]["gamedata"]["teams"]["rank"] = team_rank
        postmatch["info"]["rank"] = match_rank


def compute_objective_metrics(
    json_events: dict,
    linked_events: dict,
    events_in_match: list[str],
    team_position_id: dict,
) -> list[dict, dict]:
    """Process objective event metrics.

    The data from BUILDING_KILL, TURRET_PLATE_DESTROYED, ELITE_MONSTER_KILL, CHAMPION_KILL, CHAMPION_SPECIAL_KILL gets summarized to compute their corresponding metrics.

    Args:
    ----
        json_events (dict): bytime events.
        linked_events (dict): linked bytime events.
        events_in_match (list[str]): bytime events event types in match.
        team_position_id (dict): participant team position.

    Returns:
    -------
        list[dict, dict]: team and player metrics related to objective events.

    """
    players_metrics = []
    team_metrics = []
    if "BUILDING_KILL" in events_in_match:
        player_building_metrics, team_building_metrics = all_building_metrics(
            json_events["BUILDING_KILL"],
        )
        players_metrics += [player_building_metrics]
        team_metrics += [team_building_metrics]

    if "TURRET_PLATE_DESTROYED" in events_in_match:
        player_plate_metrics, team_plate_metrics = all_turret_plate_metrics(
            json_events["TURRET_PLATE_DESTROYED"],
        )
        players_metrics += [player_plate_metrics]
        team_metrics += [team_plate_metrics]

    if "ELITE_MONSTER_KILL" in events_in_match:
        player_elite_monster_metrics, team_elite_monster_metrics = (
            all_elite_monster_metrics(json_events["ELITE_MONSTER_KILL"])
        )
        players_metrics += [player_elite_monster_metrics]
        team_metrics += [team_elite_monster_metrics]

    if "CHAMPION_KILL" in events_in_match:
        player_kda_metrics, team_kda_metrics = all_position_kill_metrics(
            json_events["CHAMPION_KILL"],
            team_position_id,
        )

        players_metrics += [player_kda_metrics]
        team_metrics += [team_kda_metrics]
        if "CHAMPION_SPECIAL_KILL" in linked_events:
            handle_special_kill(
                json_events["CHAMPION_KILL"],
                linked_events,
            )

    return players_metrics, team_metrics


def process_item_events(
    json_events: dict,
    linked_events: dict,
    events_in_match: dict,
) -> list[dict, dict]:
    """Process item events.

    The data from ITEM_PURCHASED, ITEM_DESTROYED, ITEM_UNDO, ITEM_DESTROYED gets summarized due to compute the items used by each participant and the support quest competed event.

    Args:
    ----
        json_events (dict): bytime events.
        linked_events (dict): linked bytime events.
        events_in_match (dict): bytime events event types in match.

    Returns:
    -------
        list[dict, dict]: team and player metrics related to item events.

    """
    items_used = {}
    utility_quest = {}
    if "ITEM_PURCHASED" in events_in_match:
        items_purchased = treat_item_events(
            json_events["ITEM_PURCHASED"],
        )
        items_destroyed = {}
        items_undo = {}

    if "ITEM_DESTROYED" in events_in_match:
        items_destroyed = treat_item_events(
            json_events["ITEM_DESTROYED"],
        )
        # If items not purchased, create and empty dict to handle it later
        if not items_purchased:
            items_purchased = {}

    if "ITEM_UNDO" in events_in_match:
        items_undo = treat_item_undo_events(json_events["ITEM_UNDO"])

    if items_purchased and items_destroyed:
        items_used = compute_items_used(items_purchased, items_undo)
        utility_quest = utility_quest_completed(items_purchased, items_destroyed)

    if items_destroyed:
        create_bytime_event_from_items(
            json_events["ITEM_DESTROYED"],
            utility_quest,
            linked_events,
        )

    return items_used, utility_quest


def compute_participant_frames_metrics(
    json_participant_frames: dict,
    utility_quest_completed: dict,
) -> dict:
    """Compute the metrics from PARTICIPANT_FRAMES.

    Args:
    ----
        json_participant_frames (dict): bytime participant frame json data.
        utility_quest_completed (dict): utility's quest completed timestamp.
        legendary_items_purchased (dict): participant item history.

    Returns:
    -------
        dict:
            "goldMetrics", "minionMetrics", "jungleMonsterMetrics".

    """
    participant_metrics = defaultdict(dict)

    gold_metrics = gold_usage_metrics(
        json_participant_frames["currentGold"],
        json_participant_frames["totalGold"],
    )

    minion_metrics = all_minions_metrics(
        json_participant_frames["minionsKilled"],
        utility_quest_completed,
    )

    jungle_monster_metrics = all_jungle_minions_metrics(
        json_participant_frames["jungleMinionsKilled"],
    )

    # TODO: "alliedJungleMonstersEfficency i enemyJungleMonstersEfficency" donat que està pendent de comprovar que es compleixi:  # noqa: FIX002, TD002, TD003

    participant_id_metrics = {
        **gold_metrics,
        **minion_metrics,
        **jungle_monster_metrics,
    }
    for metric, value in participant_id_metrics.items():
        participant_metrics[metric] = value

    return dict(participant_metrics)


def merge_dicts(*dicts: dict) -> dict:
    """Merge multiple nested dictionaries. Later values overwrite earlier ones.

    Args:
    ----
        dicts (tuple): Multiple nested dicts.

    Returns:
    -------
        dict: Merged dict.

    """
    merged = {}
    for event_type_metrics in dicts:
        for metric in event_type_metrics:
            merged[metric] = event_type_metrics[metric]
    return merged


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Process some text files and integers.",
    )

    parser.add_argument("reducedFile", type=str, help="Input txt file path")
    parser.add_argument("newMetricsFile", type=str, help="Output txt file path")
    parser.add_argument(
        "--deletePreviousOutputFile",
        type=str,
        default=True,
        help="Delete the previous output file, default True",
    )

    args = parser.parse_args()

    script_dir = Path(__file__).resolve()
    reduced_path = script_dir / args.reducedFile
    new_metrics_path = script_dir / args.newMetricsFile

    if Path(args.newMetricsFile).is_file() and args.deletePreviousOutputFile:
        Path.unlink(args.newMetricsFile)

    LEVEL = logging.INFO
    logger.setLevel(LEVEL)

    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")

    Path("logs").mkdir(exist_ok=True)

    file_handler = logging.FileHandler("logs/new_metrics.log")
    file_handler.setLevel(LEVEL)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(LEVEL)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    main(args.reducedFile, args.newMetricsFile)
