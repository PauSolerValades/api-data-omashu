"""Test functions related to item events."""

import sys
import unittest
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from metrics.item_metrics import (
    compute_items_used,
    create_bytime_event_from_items,
    treat_item_events,
    treat_item_undo_events,
    utility_quest_completed,
)


class EventMetricsTests(unittest.TestCase):
    """Test item event fuctions."""

    def test_treat_item_events(self) -> None:
        """Test treat item event function."""
        item_destroyed_event = {
            "itemId": [2003, 2003, 2003],
            "participantId": [7, 1, 1],
            "timestamp": [109516, 124357, 125357],
            "eventOrd": [50, 54, 55],
        }

        partcipant_items_destroyed = treat_item_events(item_destroyed_event)
        expected_partcipant_items_destroyed = {
            7: {2003: {"timestamp": [109516], "eventOrd": [50]}},
            1: {2003: {"timestamp": [124357, 125357], "eventOrd": [54, 55]}},
        }

        self.assertEqual(
            partcipant_items_destroyed,
            expected_partcipant_items_destroyed,
        )

    def test_treat_item_undo_event(self) -> None:
        """Test treat item undo event funciton."""
        item_undo_event = {
            "afterId": [0, 0],
            "beforeId": [2022, 1042],
            "goldGain": [250, 300],
            "participantId": [8, 9],
            "timestamp": [651854, 663002],
            "eventOrd": [348, 350],
        }

        partcipant_items_undo = treat_item_undo_events(item_undo_event)
        expected_partcipant_items_undo = {8: {2022: [651854]}, 9: {1042: [663002]}}

        self.assertEqual(
            partcipant_items_undo,
            expected_partcipant_items_undo,
        )

    def test_compute_items_used(self) -> None:
        """Test compute_items_used function."""
        item_purchased_event = {
            3: {
                2003: {"timestamp": [5018, 5286], "eventOrd": [10, 11]},
            },
            5: {
                3865: {"timestamp": [8457], "eventOrd": [16]},
            },
            10: {
                3865: {"timestamp": [25660], "eventOrd": [32]},
            },
            8: {
                2022: {"timestamp": [650392, 653386], "eventOrd": [347, 349]},
            },
        }
        item_undo_event = {8: {2022: [651854]}}

        participant_items_used = compute_items_used(
            item_purchased_event,
            item_undo_event,
        )
        expected_participant_items_used = {
            "itemsUsed": {3: {2003: 2}, 5: {3865: 1}, 10: {3865: 1}, 8: {2022: 1}},
        }

        self.assertEqual(participant_items_used, expected_participant_items_used)

    def test_create_bytime_event_from_items(self) -> None:
        """Test create_bytime_event_from_items function."""
        destroy_item_events = {
            "itemId": [3865, 3865, 3866, 3866, 3513],
            "participantId": [10, 5, 5, 10, 1],
            "timestamp": [505067, 551876, 892267, 1104409, 1169721],
            "eventOrd": [500, 540, 867, 1050, 1109],
        }
        utility_quest = {
            5: {
                "questStart": {"minute": 1, "timestamp": 8457, "eventOrd": 16},
                "questCompleted": {"minute": 16, "timestamp": 909165, "eventOrd": 502},
            },
            10: {
                "questStart": {"minute": 1, "timestamp": 25660, "eventOrd": 32},
                "questCompleted": {"minute": 15, "timestamp": 842160, "eventOrd": 471},
            },
        }
        linked_events = {
            "CHAMPION_SPECIAL_KILL": {
                "killType": ["KILL_FIRST_BLOOD"],
                "killerId": [8],
                "timestamp": [200863],
                "position": [[7027, 7081]],
                "eventOrd": [99],
            },
        }

        create_bytime_event_from_items(
            destroy_item_events,
            utility_quest,
            linked_events,
        )

        expected_updated_linked_events = {
            "CHAMPION_SPECIAL_KILL": {
                "killType": ["KILL_FIRST_BLOOD"],
                "killerId": [8],
                "timestamp": [200863],
                "position": [[7027, 7081]],
                "eventOrd": [99],
            },
            "SUPPORT_QUEST": {
                "participantId": [5, 10],
                "timestampQuestStart": [8457, 25660],
                "timestampQuestCompleted": [909165, 842160],
                "questCompleted": [True, True],
                "startEventAssociated": [16, 32],
                "endEventAssociated": [502, 471],
            },
            "INVOKE_RIFT_HERALD": {
                "timestamp": [1169721],
                "eventAssociated": [1109],
                "participantId": [1],
            },
        }
        self.assertEqual(linked_events, expected_updated_linked_events)

    def test_utility_quest_completed(self) -> None:
        """Test utility_quest_completed function."""
        item_purchased_events = {
            5: {
                3865: {"timestamp": [8457], "eventOrd": [16]},
            },
            10: {
                3865: {"timestamp": [25660], "eventOrd": [32]},
                2003: {"timestamp": [26060, 26226, 547146], "eventOrd": [33, 34, 272]},
            },
        }
        item_destroyed_events = {
            5: {
                3865: {"timestamp": [576631], "eventOrd": [290]},
                3866: {"timestamp": [909165], "eventOrd": [502]},
            },
            10: {
                3865: {"timestamp": [449874], "eventOrd": [230]},
                3866: {"timestamp": [842160], "eventOrd": [471]},
            },
        }

        utility_quest = utility_quest_completed(
            item_purchased_events,
            item_destroyed_events,
        )

        expected_utility_quest = {
            5: {
                "questStart": {"minute": 1, "timestamp": 8457, "eventOrd": 16},
                "questCompleted": {"minute": 16, "timestamp": 909165, "eventOrd": 502},
            },
            10: {
                "questStart": {"minute": 1, "timestamp": 25660, "eventOrd": 32},
                "questCompleted": {"minute": 15, "timestamp": 842160, "eventOrd": 471},
            },
        }
        self.assertEqual(utility_quest, expected_utility_quest)
