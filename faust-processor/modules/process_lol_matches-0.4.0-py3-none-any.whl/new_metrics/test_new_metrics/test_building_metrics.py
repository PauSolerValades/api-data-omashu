"""Test building funcitons."""

import sys
import unittest
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from metrics.building_metrics import all_building_metrics, all_turret_plate_metrics


class EventMetricsTests(unittest.TestCase):
    """Test building event fuctions."""

    def test_building(self) -> None:
        """Test building function."""
        building_events = {
            "killerId": [6, 6, 9, 8],
            "buildingType": [
                "TOWER_BUILDING",
                "TOWER_BUILDING",
                "TOWER_BUILDING",
                "INHIBITOR_BUILDING",
            ],
            "laneType": ["TOP_LANE", "TOP_LANE", "TOP_LANE", "TOP_LANE"],
            "teamId": [100, 100, 100, 100],
            "towerType": ["OUTER_TURRET", "INNER_TURRET", "BASE_TURRET", None],
            "assistingParticipantIds": [[], [7], [10], [9, 10]],
        }
        player_building_metrics, team_building_metrics = all_building_metrics(
            building_events,
        )
        expected_player_building_metrics = {
            "buildingKill": {6: 2, 8: 1},
            "turretKill": {6: 2},
            "topLaneTurretKill": {6: 2},
            "buildingAssist": {7: 1, 10: 2, 9: 1},
            "turretAssist": {7: 1, 10: 1},
            "topLaneTurretAssist": {7: 1, 10: 1},
            "inhibitorKill": {8: 1},
            "topLaneInhibitorKill": {8: 1},
            "inhibitorAssist": {9: 1, 10: 1},
            "topLaneInhibitorAssist": {9: 1, 10: 1},
        }
        expected_team_building_metrics = {
            "buildingKill": {200: 3},
            "turretKill": {200: 2},
            "topLaneTurretKill": {200: 2},
            "buildingAssist": {200: 4},
            "turretAssist": {200: 2},
            "topLaneTurretAssist": {200: 2},
            "openedLanes": {200: 1},
            "inhibitorKill": {200: 1},
            "topLaneInhibitorKill": {200: 1},
            "inhibitorAssist": {200: 2},
            "topLaneInhibitorAssist": {200: 2},
        }

        self.assertEqual(
            player_building_metrics,
            expected_player_building_metrics,
        )
        self.assertEqual(
            team_building_metrics,
            expected_team_building_metrics,
        )

    def test_all_turret_plate_metrics(self) -> None:
        """Test all_turret_plate_metrics function."""
        turret_plate_events = {
            "killerId": [0, 10, 0],
            "laneType": ["MID_LANE", "BOT_LANE", "TOP_LANE"],
            "teamId": [200, 100, 100],
            "timestamp": [441212, 470120, 553719],
            "position": [[8955, 8510], [10504, 1029], [5846, 6396]],
            "eventOrd": [225, 236, 277, 379, 391, 394, 402, 434, 439, 454],
        }
        player_plate_metrics, team_plate_metrics = all_turret_plate_metrics(
            turret_plate_events,
        )
        expected_player_plate_metrics = {
            "turretPlateKill": {10: 1},
            "botLaneTurretPlateKill": {10: 1},
        }
        expected_team_plate_metrics = {
            "midLane200TurretPlateKilledByMinions": {100: 1},
            "turretPlateKill": {200: 1},
            "botLaneTurretPlateKill": {200: 1},
            "topLane100TurretPlateKilledByMinions": {200: 1},
        }
        self.assertEqual(player_plate_metrics, expected_player_plate_metrics)
        self.assertEqual(team_plate_metrics, expected_team_plate_metrics)
