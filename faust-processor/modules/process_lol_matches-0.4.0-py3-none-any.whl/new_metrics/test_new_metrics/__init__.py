"""Test package for new_metrics."""
