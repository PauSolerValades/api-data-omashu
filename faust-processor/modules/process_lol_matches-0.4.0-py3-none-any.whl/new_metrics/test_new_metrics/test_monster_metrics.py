"""Test elite monster funcitons."""

import sys
import unittest
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from metrics.monster_metrics import all_elite_monster_metrics


class EventMetricsTests(unittest.TestCase):
    """Test elite monster event fuctions."""

    def test_elite_monster(self) -> None:
        """Test elite monster fuction."""
        elite_monster_events = {
            "killerId": [7, 2, 2],
            "killerTeamId": [200, 100, 100],
            "monsterType": ["DRAGON", "HORDE", "HORDE"],
            "monsterSubType": ["WATER_DRAGON", None, None],
            "assistingParticipantIds": [[6], [1], []],
        }
        player_elite_monster_metrics, team_elite_monster_metrics = (
            all_elite_monster_metrics(elite_monster_events)
        )
        expected_elite_monster_metrics = {
            "eliteMonsterKill": {7: 1, 2: 2},
            "dragonKill": {7: 1},
            "waterDragonKill": {7: 1},
            "eliteMonsterAssist": {6: 1, 1: 1},
            "dragonAssist": {6: 1},
            "waterDragonAssist": {6: 1},
            "voidGrubKill": {2: 2},
            "voidMonsterKill": {2: 2},
            "voidGrubAssist": {1: 1},
            "voidMonsterAssist": {1: 1},
        }
        expected_team_elite_monster_metrics = {
            "eliteMonsterKill": {200: 1, 100: 2},
            "dragonKill": {200: 1},
            "waterDragonKill": {200: 1},
            "eliteMonsterAssist": {200: 1, 100: 1},
            "dragonAssist": {200: 1},
            "waterDragonAssist": {200: 1},
            "voidGrubKill": {100: 2},
            "voidMonsterKill": {100: 2},
            "voidGrubAssist": {100: 1},
            "voidMonsterAssist": {100: 1},
        }

        self.assertEqual(
            player_elite_monster_metrics,
            expected_elite_monster_metrics,
        )
        self.assertEqual(
            team_elite_monster_metrics,
            expected_team_elite_monster_metrics,
        )
