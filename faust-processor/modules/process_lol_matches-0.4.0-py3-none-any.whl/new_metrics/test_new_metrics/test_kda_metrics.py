"""Test functions related to kda events."""

import sys
import unittest
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from metrics.kda_metrics import all_position_kill_metrics, handle_special_kill


class EventMetricsTests(unittest.TestCase):
    """Test kda event fuctions."""

    def test_all_poisition_kill_metrics(self) -> None:
        """Test compute metrics from kda events."""
        team_position_id = {
            "1": "TOP",
            "2": "JUNGLE",
            "3": "MIDDLE",
            "4": "BOTTOM",
            "5": "UTILITY",
            "6": "TOP",
            "7": "JUNGLE",
            "8": "MIDDLE",
            "9": "BOTTOM",
            "10": "UTILITY",
        }
        kda_events = {
            "victimDamageReceived": {},
            "victimDamageDealt": {},
            "bounty": [400, 300, 219, 219],
            "killStreakLength": [0, 0, 0, 1],
            "killerId": [8, 2, 8, 8],
            "shutdownBounty": [0, 0, 0, 0],
            "timestamp": [200863, 366659, 527537, 628184],
            "victimId": [3, 8, 3, 3],
            "position": [[7403, 7630], [8260, 7975], [7480, 7603], [7567, 7610]],
            "eventOrd": [99, 177, 256, 315],
            "assistingParticipantIds": [[], [3], [], []],
        }
        player_kda_metrics, team_kda_metrics = all_position_kill_metrics(
            kda_events,
            team_position_id,
        )
        expected_player_kda_metrics = {
            "enemyChampionKill": {8: 3, 2: 1},
            "enemyMiddleKill": {8: 3, 2: 1},
            "enemyChampionDeathAssisted": {3: 1},
            "alliedJungleKillAssist": {3: 1},
            "enemyMiddleDeathAssisted": {3: 1},
        }
        expected_team_kda_metrics = {
            "enemyChampionKill": {200: 3, 100: 1},
            "enemyMiddleKill": {200: 3, 100: 1},
            "enemyChampionDeathAssisted": {100: 1},
            "alliedJungleKillAssist": {100: 1},
        }
        self.assertEqual(player_kda_metrics, expected_player_kda_metrics)
        self.assertEqual(team_kda_metrics, expected_team_kda_metrics)

    def test_handle_special_kill(self) -> None:
        """Test process champion special kill events."""
        kda_events = {
            "victimDamageReceived": {},
            "victimDamageDealt": {},
            "bounty": [400, 300, 300],
            "killStreakLength": [0, 4, 3],
            "killerId": [1, 4, 1],
            "shutdownBounty": [0, 0, 50],
            "timestamp": [146373, 932101, 1652157],
            "victimId": [6, 7, 7],
            "position": [[2984, 12651], [13217, 3924], [12834, 13308]],
            "eventOrd": [85, 910, 1547],
            "assistingParticipantIds": [[], [5], []],
        }
        linked_events = {
            "CHAMPION_SPECIAL_KILL": {
                "killType": ["KILL_FIRST_BLOOD", "KILL_MULTI", "KILL_ACE"],
                "killerId": [1, 4, 1],
                "timestamp": [146373, 932101, 1652157],
                "position": [[2444, 12079], [13238, 3615], [12416, 13198]],
                "eventOrd": [85, 910, 1547],
                "multiKillLength": [2],
            },
        }
        handle_special_kill(kda_events, linked_events)
        expected_linked_events = {
            "CHAMPION_SPECIAL_KILL": {
                "killType": ["KILL_FIRST_BLOOD", "KILL_MULTI", "KILL_ACE"],
                "killerId": [1, 4, 1],
                "timestamp": [146373, 932101, 1652157],
                "position": [[2444, 12079], [13238, 3615], [12416, 13198]],
                "eventOrd": [85, 910, 1547],
                "multiKillLength": [2],
            },
            "FIRST_BLOOD": {
                "killerId": [1],
                "victimId": [6],
                "timestamp": [146373],
                "eventOrd": [85],
            },
            "CHAMPION_MULTI_KILL": {
                "killerId": [4, 4],
                "victims": [6, 7],
                "timestamps": [146373, 932101],
                "eventOrd": [85, 910],
            },
            "CHAMPION_KILL_ACE": {
                "killerId": [1],
                "victimId": [7],
                "timestamp": [1652157],
                "eventOrd": [1547],
            },
        }
        self.assertEqual(linked_events, expected_linked_events)
